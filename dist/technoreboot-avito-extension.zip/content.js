// Technoreboot Avito Content Script (DOM Extractor & Safe Form Fill Adapter v0.2.29)

let pageInitialData = null;

function extractAvitoItemId(url, htmlContent) {
    if (!url) url = window.location.href;
    const match = url.match(/_(\d+)(?:\?|$)/) || url.match(/\/(\d{8,14})(?:\?|$)/) || url.match(/itemId=(\d+)/i) || url.match(/item_id=(\d+)/i);
    if (match) return match[1];

    try {
        const canonical = document.querySelector('link[rel="canonical"]');
        if (canonical && canonical.href) {
            const canMatch = canonical.href.match(/_(\d+)(?:\?|$)/) || canonical.href.match(/\/(\d{8,14})(?:\?|$)/);
            if (canMatch) return canMatch[1];
        }
        const itemEl = document.querySelector('[data-item-id]');
        if (itemEl && itemEl.getAttribute('data-item-id')) {
            return itemEl.getAttribute('data-item-id');
        }
        const metaItem = document.querySelector('meta[name="item-id"], meta[property="al:ios:url"], meta[property="al:android:url"]');
        if (metaItem && metaItem.content) {
            const m = metaItem.content.match(/\d{8,14}/);
            if (m) return m[0];
        }
    } catch (e) {}

    // Fallback if numbers exist in the item path
    if (url.includes('/items/') || url.includes('/tovary/') || url.includes('avito.ru')) {
        const digits = url.match(/\d{6,14}/);
        if (digits) return digits[0];
    }
    return null;
}

function parseJsonLd() {
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const script of scripts) {
        try {
            const data = JSON.parse(script.textContent);
            if (data && (data["@type"] === "Product" || data["@type"] === "Offer" || data.name || data["@graph"])) {
                return data;
            }
        } catch (e) {}
    }
    return null;
}

const HIGH_RES_THRESHOLD = 800;

function validateListingImageUrl(url) {
    if (!url || typeof url !== 'string') return null;
    let u = url.trim();
    if (u.startsWith('//')) u = 'https:' + u;
    if (!u.startsWith('http://') && !u.startsWith('https://')) return null;

    const lower = u.toLowerCase();
    if (lower.includes('/avatar/') || lower.includes('/avatars/') ||
        lower.includes('/icons/') || lower.includes('/logos/') ||
        lower.includes('/banner/') ||
        lower.endsWith('.svg') || lower.startsWith('data:') ||
        lower.endsWith('.mp4') || lower.endsWith('.m3u8') || lower.endsWith('.webm') ||
        lower.includes('video.avito.st') || lower.includes('/video/')) {
        return null;
    }

    return u;
}

function upgradeAvitoImageUrlToMaxQuality(url) {
    if (!url || typeof url !== 'string') return url;
    let u = url;

    // Only dimension path prefix /140x105/ or /640x480/ can be upgraded to /1280x960/
    if (u.match(/\/\d+x\d+\//)) {
        u = u.replace(/\/\d+x\d+\//, '/1280x960/');
    }

    // NEVER regex replace /image/1/ signed hash tokens!
    return u;
}

function getCanonicalAvitoImageIdentity(url) {
    if (!url || typeof url !== 'string') return '';

    const pathOnly = url.split('?')[0];
    let cleanPath = pathOnly.replace(/^https?:\/\/[^\/]+\//i, '');
    cleanPath = cleanPath.replace(/^(?:image\/\d+\/|\d+x\d+\/)+/i, '');
    const filename = cleanPath.split('/').pop() || cleanPath;
    const token = filename.replace(/^\d+\./, '');

    // Format 1: 1.YIZY7ra4... -> prefix is YIZY7
    const laMatch = token.match(/^([A-Za-z0-9_-]+?)[a-zA-Z]a\d/i);
    if (laMatch && laMatch[1] && laMatch[1].length >= 2) {
        return `avito_photo_${laMatch[1]}`;
    }

    // Format 2: dimension filenames like 123456789.jpg
    const tokenNoExt = token.replace(/\.(?:jpg|jpeg|webp|png)$/i, '');
    if (/^\d{6,}$/.test(tokenNoExt)) {
        return `avito_photo_${tokenNoExt}`;
    }

    // Format 3: hash tokens with dots: 1.TOKEN.HASH -> take first full segment
    const parts = tokenNoExt.split('.');
    if (parts.length >= 2) {
        return `avito_photo_${parts[0]}_${parts[1].substring(0, 16)}`;
    }

    const cleanName = tokenNoExt.replace(/[^A-Za-z0-9_-]/g, '');
    if (cleanName.length >= 2) {
        return `avito_photo_${cleanName}`;
    }

    return pathOnly;
}

function extractAvitoResolutionVersion(url) {
    if (!url) return 0;
    const pathOnly = url.split('?')[0];
    let cleanPath = pathOnly.replace(/^https?:\/\/[^\/]+\//i, '');
    cleanPath = cleanPath.replace(/^(?:image\/\d+\/|\d+x\d+\/)+/i, '');
    const filename = cleanPath.split('/').pop() || cleanPath;
    const token = filename.replace(/^\d+\./, '');

    const m = token.match(/[a-zA-Z]a(\d)/);
    if (m) return parseInt(m[1], 10);
    return 0;
}

function getImageQualityScore(candidateInput) {
    const url = typeof candidateInput === 'string' ? candidateInput : ((candidateInput && candidateInput.url) || '');
    if (!url) return 0;

    let w = typeof candidateInput === 'object' ? (candidateInput.width || 0) : 0;
    let h = typeof candidateInput === 'object' ? (candidateInput.height || 0) : 0;
    let srcsetW = typeof candidateInput === 'object' ? (candidateInput.srcsetW || 0) : 0;

    let explicitBonus = 0;

    const dimMatch = url.match(/\/(?:(\d+)x(\d+))\//);
    if (dimMatch && dimMatch[1] && dimMatch[2]) {
        const pathW = parseInt(dimMatch[1], 10);
        const pathH = parseInt(dimMatch[2], 10);
        w = Math.max(w, pathW);
        h = Math.max(h, pathH);
        explicitBonus = 5;
    }

    let baseArea = 0;
    if (w > 0 && h > 0) {
        baseArea = w * h;
    } else if (srcsetW > 0) {
        baseArea = srcsetW * Math.round(srcsetW * 0.75);
    }

    const version = extractAvitoResolutionVersion(url);
    const laBonus = version * 10;

    if (version > 0 && baseArea === 0) {
        if (version >= 4) baseArea = 1280 * 960;
        else if (version === 3) baseArea = 640 * 480;
        else if (version === 2) baseArea = 208 * 156;
        else if (version === 1) baseArea = 140 * 105;
    }

    if (baseArea === 0 && url.includes('.img.avito.st/image/1/')) {
        baseArea = 1280 * 960;
    }

    if (baseArea === 0 && url.includes('.img.avito.st/')) {
        baseArea = 640 * 480;
    }

    return baseArea + explicitBonus + laBonus;
}

function extractBestUrlFromSrcset(srcset) {
    const candidates = parseSrcsetCandidates(srcset);
    if (candidates.length === 0) return null;
    return candidates[0].url;
}

function parseSrcsetCandidates(srcset) {
    if (!srcset || typeof srcset !== 'string') return [];
    const entries = srcset.split(',');
    const candidates = [];

    for (const entry of entries) {
        const trimmed = entry.trim();
        if (!trimmed) continue;
        const parts = trimmed.split(/\s+/);
        if (parts.length === 0) continue;
        const rawUrl = parts[0];
        const valid = validateListingImageUrl(rawUrl);
        if (!valid) continue;

        let width = 0;
        let descriptor = parts[1] || '';
        if (descriptor.endsWith('w')) {
            width = parseInt(descriptor.slice(0, -1), 10) || 0;
        } else if (descriptor.endsWith('x')) {
            const mult = parseFloat(descriptor.slice(0, -1)) || 1;
            width = Math.round(mult * 640);
        }

        candidates.push({
            url: valid,
            srcsetW: width,
            score: getImageQualityScore({ url: valid, srcsetW: width })
        });
    }

    candidates.sort((a, b) => b.score - a.score);
    return candidates;
}

function parseJsonLdImages(jsonLd) {
    const urls = [];
    if (!jsonLd) return urls;

    function addCandidate(raw) {
        const valid = validateListingImageUrl(raw);
        if (valid && !urls.includes(valid)) {
            urls.push(valid);
        }
    }

    const items = Array.isArray(jsonLd) ? jsonLd : [jsonLd];
    for (const node of items) {
        if (!node || typeof node !== 'object') continue;

        if (node.image) {
            if (typeof node.image === 'string') {
                addCandidate(node.image);
            } else if (Array.isArray(node.image)) {
                node.image.forEach(item => {
                    if (typeof item === 'string') addCandidate(item);
                    else if (item && item.contentUrl) addCandidate(item.contentUrl);
                    else if (item && item.url) addCandidate(item.url);
                });
            } else if (typeof node.image === 'object') {
                if (node.image.contentUrl) addCandidate(node.image.contentUrl);
                if (node.image.url) addCandidate(node.image.url);
            }
        }

        if (Array.isArray(node['@graph'])) {
            node['@graph'].forEach(gNode => {
                if (gNode && gNode.image) {
                    if (typeof gNode.image === 'string') addCandidate(gNode.image);
                    else if (Array.isArray(gNode.image)) {
                        gNode.image.forEach(item => {
                            if (typeof item === 'string') addCandidate(item);
                            else if (item && item.contentUrl) addCandidate(item.contentUrl);
                            else if (item && item.url) addCandidate(item.url);
                        });
                    } else if (typeof gNode.image === 'object') {
                        if (gNode.image.contentUrl) addCandidate(gNode.image.contentUrl);
                        if (gNode.image.url) addCandidate(gNode.image.url);
                    }
                }
            });
        }
    }
    return urls;
}

const EXCLUDED_DATA_KEYS = new Set([
    'recommendations', 'similar', 'similaritems', 'similar-items', 'recommendationitems',
    'seller', 'selleritems', 'author', 'user', 'profile', 'popular',
    'related', 'relateditems', 'otheritems', 'other-items',
    'buyerprotection', 'buyer-protection', 'ads', 'promo', 'banner', 'banners',
    'serp', 'catalog', 'vip', 'vas'
]);

function extractAvitoUrlsFromObject(obj, depth = 0, seen = new Set()) {
    if (!obj || depth > 25) return [];
    if (typeof obj === 'string') {
        const valid = validateListingImageUrl(obj);
        if (valid && !seen.has(valid)) {
            seen.add(valid);
            return [valid];
        }
        return [];
    }
    if (typeof obj !== 'object') return [];

    const found = [];
    if (Array.isArray(obj)) {
        for (const item of obj) {
            found.push(...extractAvitoUrlsFromObject(item, depth + 1, seen));
        }
        return found;
    }

    for (const [k, v] of Object.entries(obj)) {
        const lowerK = k.toLowerCase().replace(/[^a-z0-9_-]/g, '');
        if (EXCLUDED_DATA_KEYS.has(lowerK) || lowerK.includes('recommend') || lowerK.includes('similar') || lowerK.includes('seller') || lowerK.includes('otheritem')) {
            continue;
        }
        found.push(...extractAvitoUrlsFromObject(v, depth + 1, seen));
    }
    return found;
}

function parseItemImagesFromJsonObject(data) {
    if (!data || typeof data !== 'object') return [];
    const urls = [];
    const seen = new Set();

    // 1. Check item node (data.item, data.state.item, data.props.pageProps.item)
    const itemNode = data.item || (data.state && data.state.item) || (data.props && data.props.pageProps && data.props.pageProps.item);
    if (itemNode && typeof itemNode === 'object') {
        const itemPhotos = extractAvitoUrlsFromObject(itemNode, 0, seen);
        urls.push(...itemPhotos);
    }

    // 2. Check gallery widgets specifically
    const widgets = data.widgets || (data.state && data.state.widgets) || (data.props && data.props.pageProps && data.props.pageProps.widgets);
    if (widgets && typeof widgets === 'object') {
        for (const [wKey, wVal] of Object.entries(widgets)) {
            const lowerWKey = wKey.toLowerCase();
            if (lowerWKey.includes('gallery') || lowerWKey.includes('image-frame') || lowerWKey.includes('item-view')) {
                if (!lowerWKey.includes('recommend') && !lowerWKey.includes('similar') && !lowerWKey.includes('seller')) {
                    const widgetPhotos = extractAvitoUrlsFromObject(wVal, 0, seen);
                    urls.push(...widgetPhotos);
                }
            }
        }
    }

    // 3. Fallback only if no item or gallery widgets found
    if (urls.length === 0) {
        const fallbackPhotos = extractAvitoUrlsFromObject(data, 0, seen);
        urls.push(...fallbackPhotos);
    }

    return urls;
}

function extractJsonAssignedToVar(text, varName) {
    if (!text || typeof text !== 'string') return null;
    const idx = text.indexOf(varName);
    if (idx === -1) return null;

    const eqIdx = text.indexOf('=', idx);
    if (eqIdx === -1) return null;

    let startIdx = -1;
    let isQuotedString = false;
    for (let i = eqIdx + 1; i < text.length; i++) {
        const c = text[i];
        if (c === '{') {
            startIdx = i;
            break;
        }
        if (c === '"' || c === "'") {
            startIdx = i;
            isQuotedString = true;
            break;
        }
        if (c !== ' ' && c !== '\t' && c !== '\r' && c !== '\n') {
            break;
        }
    }
    if (startIdx === -1) return null;

    if (isQuotedString) {
        const quoteChar = text[startIdx];
        let endIdx = -1;
        let escape = false;
        for (let i = startIdx + 1; i < text.length; i++) {
            if (escape) {
                escape = false;
                continue;
            }
            if (text[i] === '\\') {
                escape = true;
                continue;
            }
            if (text[i] === quoteChar) {
                endIdx = i;
                break;
            }
        }
        if (endIdx !== -1) {
            let strVal = text.substring(startIdx + 1, endIdx);
            try {
                if (strVal.includes('%7B') || strVal.includes('%22') || strVal.includes('%3A')) {
                    strVal = decodeURIComponent(strVal);
                }
                let parsed = JSON.parse(strVal);
                if (typeof parsed === 'string') {
                    parsed = JSON.parse(parsed);
                }
                if (typeof parsed === 'object' && parsed) return parsed;
            } catch (e) {
                try {
                    let cleaned = strVal.replace(/\\"/g, '"').replace(/\\\\/g, '\\').replace(/\\\//g, '/');
                    let parsed = JSON.parse(cleaned);
                    if (typeof parsed === 'string') parsed = JSON.parse(parsed);
                    if (typeof parsed === 'object' && parsed) return parsed;
                } catch (e2) {}
            }
        }
    }

    // Direct balanced brace object parser
    let firstBrace = text.indexOf('{', eqIdx);
    if (firstBrace !== -1) {
        let depth = 0;
        let inString = false;
        let escape = false;

        for (let i = firstBrace; i < text.length; i++) {
            const char = text[i];
            if (escape) {
                escape = false;
                continue;
            }
            if (char === '\\') {
                escape = true;
                continue;
            }
            if (char === '"') {
                inString = !inString;
                continue;
            }
            if (!inString) {
                if (char === '{') depth++;
                else if (char === '}') {
                    depth--;
                    if (depth === 0) {
                        const jsonStr = text.substring(firstBrace, i + 1);
                        try {
                            return JSON.parse(jsonStr);
                        } catch (e) {}
                        break;
                    }
                }
            }
        }
    }
    return null;
}

function extractPhotosFromEmbeddedState() {
    const urls = [];
    const seen = new Set();

    function addUrl(u) {
        const valid = validateListingImageUrl(u);
        if (valid && !seen.has(valid)) {
            seen.add(valid);
            urls.push(valid);
        }
    }

    // 1. Direct main-world initialData check
    if (pageInitialData) {
        const photos = parseItemImagesFromJsonObject(pageInitialData);
        photos.forEach(addUrl);
    }

    // 2. Parse structured JSON from script tags
    const scripts = document.querySelectorAll('script');
    for (const script of scripts) {
        const text = script.textContent || '';
        if (text.includes('__initialData__') || text.includes('__NEXT_DATA__') || text.includes('__INITIAL_STATE__') || text.includes('window.__state__') || text.includes('initialData')) {
            for (const varName of ['__initialData__', '__INITIAL_STATE__', '__NEXT_DATA__', 'window.__state__', 'initialData', '__state__']) {
                if (text.includes(varName)) {
                    const parsed = extractJsonAssignedToVar(text, varName);
                    if (parsed) {
                        const photos = parseItemImagesFromJsonObject(parsed);
                        photos.forEach(addUrl);
                    }
                }
            }
        }
    }
    return urls;
}

function extractPhotosFromDom() {
    const rawCandidates = [];
    const seen = new Set();

    function addUrl(u) {
        const valid = validateListingImageUrl(u);
        if (valid && !seen.has(valid)) {
            seen.add(valid);
            rawCandidates.push(valid);
        }
    }

    // Strictly scope to the listing gallery container
    const galleryContainer = document.querySelector('[data-marker="item-view/gallery"]') ||
                             document.querySelector('[data-marker="gallery"]') ||
                             document.querySelector('.style-item-view-gallery-') ||
                             document.querySelector('.gallery-root') ||
                             document.querySelector('[data-marker="image-frame/image-wrapper"]') ||
                             document.querySelector('[data-marker="gallery/list"]') ||
                             document.querySelector('[data-marker="item-view/main"] [data-marker*="gallery"]') ||
                             document.querySelector('[data-marker="item-view/main"]');

    if (!galleryContainer) {
        return rawCandidates;
    }

    function isInsideExcluded(el) {
        if (!el || !el.closest) return false;
        return !!(el.closest('[data-marker="seller-info"]') ||
                  el.closest('[data-marker="user-info"]') ||
                  el.closest('.seller-info-avatar') ||
                  el.closest('[data-marker="recommendations"]') ||
                  el.closest('[data-marker="similar-items"]') ||
                  el.closest('[data-marker="items-carousel"]') ||
                  el.closest('[data-marker="seller-items"]') ||
                  el.closest('.similar-items') ||
                  el.closest('.recommendations-root') ||
                  el.closest('.serp-item'));
    }

    // 1. Scan links wrapping gallery images
    const links = galleryContainer.querySelectorAll('a[href*="img.avito.st"]');
    links.forEach(a => {
        if (isInsideExcluded(a)) return;
        addUrl(a.href);
    });

    // 2. Scan elements with data-url / data-src / data-large / data-full / data-high-res / data-preview
    const dataEls = galleryContainer.querySelectorAll('[data-url*="img.avito.st"], [data-src*="img.avito.st"], [data-large*="img.avito.st"], [data-full*="img.avito.st"], [data-high-res*="img.avito.st"], [data-preview*="img.avito.st"], [data-img*="img.avito.st"]');
    dataEls.forEach(el => {
        if (isInsideExcluded(el)) return;
        ['data-url', 'data-src', 'data-large', 'data-full', 'data-high-res', 'data-preview', 'data-img'].forEach(attr => {
            const val = el.getAttribute(attr);
            if (val) addUrl(val);
        });
    });

    // 3. Scan img and picture source elements inside gallery
    const selector = [
        '[data-marker="image-frame/image-wrapper"] img',
        '[data-marker="gallery/image"] img',
        '[data-marker="slider-image/image"] img',
        '[data-marker*="image"] img',
        '[data-marker*="gallery"] img',
        '[data-marker*="slider"] img',
        'picture source[srcset]',
        'picture img',
        'ul[data-marker="gallery/list"] li img',
        'div[class*="gallery"] img',
        'div[class*="image-frame"] img',
        '.gallery-img',
        '.image-frame-wrapper img',
        '.gallery-list img',
        'img[src*="img.avito.st"]',
        'img[data-src*="img.avito.st"]'
    ].join(', ');

    const els = galleryContainer.querySelectorAll(selector);
    els.forEach(el => {
        if (isInsideExcluded(el)) return;

        const parentLink = el.closest('a');
        if (parentLink && parentLink.href && parentLink.href.includes('img.avito.st') && !isInsideExcluded(parentLink)) {
            addUrl(parentLink.href);
        }

        const srcset = el.getAttribute('srcset') || el.getAttribute('data-srcset');
        if (srcset) {
            const candidates = parseSrcsetCandidates(srcset);
            candidates.forEach(c => addUrl(c.url));
        }

        if (el.src) addUrl(el.src);
        if (el.dataset && el.dataset.src) addUrl(el.dataset.src);
    });

    // 4. Scan elements with background-image style inside gallery
    const bgEls = galleryContainer.querySelectorAll('[style*="img.avito.st"]');
    bgEls.forEach(el => {
        if (isInsideExcluded(el)) return;
        const style = el.getAttribute('style') || '';
        const match = style.match(/url\(['"]?(https?:\/\/[^\'")\s]+?\.img\.avito\.st[^\'")\s]+)['"]?\)/i);
        if (match && match[1]) {
            addUrl(match[1]);
        }
    });

    return rawCandidates;
}

function extractAllPhotos(jsonLd, extraUrls = []) {
    const rawUrls = [];

    // Collect ALL photos from JSON-LD, embedded state, DOM gallery, and active walker
    rawUrls.push(...parseJsonLdImages(jsonLd));
    rawUrls.push(...extractPhotosFromEmbeddedState());
    rawUrls.push(...extractPhotosFromDom());
    if (Array.isArray(extraUrls) && extraUrls.length > 0) {
        rawUrls.push(...extraUrls);
    }

    const groupsMap = new Map(); // canonicalKey -> [urls]
    const keyOrder = [];
    const seenUrls = new Set();

    for (let raw of rawUrls) {
        let validUrl = validateListingImageUrl(raw);
        if (!validUrl) continue;

        // Upgrade low-res dimension/version tags to maximum quality
        validUrl = upgradeAvitoImageUrlToMaxQuality(validUrl);

        if (seenUrls.has(validUrl)) continue;
        seenUrls.add(validUrl);

        const key = getCanonicalAvitoImageIdentity(validUrl);
        if (!groupsMap.has(key)) {
            groupsMap.set(key, []);
            keyOrder.push(key);
        }
        groupsMap.get(key).push(validUrl);
    }

    // Pick EXACTLY ONE single highest-quality variant for each distinct photo key (NO DUPLICATES)
    const uniquePhotos = [];

    for (const key of keyOrder) {
        const variants = groupsMap.get(key) || [];
        if (variants.length === 0) continue;

        let bestVariant = variants[0];
        let maxScore = getImageQualityScore(bestVariant);
        for (let i = 1; i < variants.length; i++) {
            const score = getImageQualityScore(variants[i]);
            if (score > maxScore) {
                maxScore = score;
                bestVariant = variants[i];
            }
        }

        uniquePhotos.push({
            url: bestVariant,
            position: uniquePhotos.length
        });
    }

    return uniquePhotos;
}

function extractCharacteristicsFromJsonObject(obj, itemId) {
    const characteristics = {};
    if (!obj || typeof obj !== 'object') return characteristics;

    function addParam(key, val) {
        if (!key || typeof key !== 'string') return;
        const cleanKey = key.trim().replace(/:$/, '');
        if (!cleanKey) return;
        
        let cleanVal = '';
        if (typeof val === 'string') {
            cleanVal = val.trim();
        } else if (typeof val === 'number' || typeof val === 'boolean') {
            cleanVal = String(val);
        } else if (Array.isArray(val)) {
            cleanVal = val.map(v => typeof v === 'object' && v ? (v.title || v.name || v.value || JSON.stringify(v)) : String(v)).filter(Boolean).join(', ');
        } else if (val && typeof val === 'object') {
            cleanVal = val.title || val.name || val.value || val.description || val.text || '';
        }
        
        if (cleanKey && cleanVal && !characteristics[cleanKey]) {
            if (!cleanKey.startsWith('Показать') && !cleanKey.startsWith('Написать') && cleanKey.length < 100 && cleanVal.length < 500) {
                characteristics[cleanKey] = cleanVal;
            }
        }
    }

    function processParamsArray(arr) {
        if (!Array.isArray(arr)) return;
        for (const item of arr) {
            if (!item || typeof item !== 'object') continue;
            const k = item.title || item.name || item.key || item.label || item.propertyName;
            const v = item.value !== undefined ? item.value : (item.description || item.text || item.values || item.propertyValue);
            if (k && v !== undefined) {
                addParam(k, v);
            }
        }
    }

    function processParamsDict(dict) {
        if (!dict || typeof dict !== 'object' || Array.isArray(dict)) return;
        for (const [k, v] of Object.entries(dict)) {
            if (typeof v === 'string' || typeof v === 'number' || Array.isArray(v)) {
                addParam(k, v);
            } else if (v && typeof v === 'object' && (v.title || v.name || v.value || v.description)) {
                addParam(k, v.value || v.title || v.name || v.description);
            }
        }
    }

    function traverse(node, depth) {
        if (!node || typeof node !== 'object' || depth > 10) return;

        if (node.params && Array.isArray(node.params)) processParamsArray(node.params);
        else if (node.params && typeof node.params === 'object') processParamsDict(node.params);

        if (node.parameters && Array.isArray(node.parameters)) processParamsArray(node.parameters);
        else if (node.parameters && typeof node.parameters === 'object') processParamsDict(node.parameters);

        if (node.properties && Array.isArray(node.properties)) processParamsArray(node.properties);
        else if (node.properties && typeof node.properties === 'object') processParamsDict(node.properties);

        if (node.characteristics && Array.isArray(node.characteristics)) processParamsArray(node.characteristics);
        else if (node.characteristics && typeof node.characteristics === 'object') processParamsDict(node.characteristics);

        if (node.itemParams && Array.isArray(node.itemParams)) processParamsArray(node.itemParams);
        else if (node.itemParams && typeof node.itemParams === 'object') processParamsDict(node.itemParams);

        if (node.paramsList && Array.isArray(node.paramsList)) processParamsArray(node.paramsList);
        else if (node.paramsList && typeof node.paramsList === 'object') processParamsDict(node.paramsList);

        if (node.shortParams && Array.isArray(node.shortParams)) processParamsArray(node.shortParams);
        if (node.fullParams && Array.isArray(node.fullParams)) processParamsArray(node.fullParams);

        if (Array.isArray(node)) {
            for (const item of node) {
                traverse(item, depth + 1);
            }
        } else {
            for (const [key, val] of Object.entries(node)) {
                if (key.includes('recommendation') || key.includes('similar') || key.includes('seller') || key.includes('banner')) continue;
                if (typeof val === 'object' && val !== null) {
                    traverse(val, depth + 1);
                }
            }
        }
    }

    traverse(obj, 0);
    return characteristics;
}

function extractCharacteristicsFromJsonLd(jsonLd) {
    const characteristics = {};
    if (!jsonLd) return characteristics;

    if (Array.isArray(jsonLd.additionalProperty)) {
        for (const prop of jsonLd.additionalProperty) {
            if (prop && prop.name && prop.value !== undefined) {
                characteristics[String(prop.name).trim()] = String(prop.value).trim();
            }
        }
    }

    if (jsonLd.disambiguatingDescription && typeof jsonLd.disambiguatingDescription === 'string') {
        const lines = jsonLd.disambiguatingDescription.split('\n');
        for (const line of lines) {
            if (line.includes(':')) {
                const idx = line.indexOf(':');
                const k = line.slice(0, idx).trim();
                const v = line.slice(idx + 1).trim();
                if (k && v && !characteristics[k]) {
                    characteristics[k] = v;
                }
            }
        }
    }

    return characteristics;
}

function safelyExpandCharacteristicsDom() {
    try {
        // Strictly scope to item params containers only - NEVER click links (<a>) or global page elements
        const paramsContainers = document.querySelectorAll('[data-marker="item-view/item-params"], [data-marker="item-properties/list"], [data-marker="item-params/list"], [class*="params-paramsList"]');
        paramsContainers.forEach(container => {
            const buttons = container.querySelectorAll('button');
            buttons.forEach(btn => {
                if (btn && btn.tagName && btn.tagName.toLowerCase() === 'button' && !btn.getAttribute('href') && !btn.closest('a')) {
                    const marker = (btn.getAttribute('data-marker') || '').toLowerCase();
                    const text = (btn.textContent || '').toLowerCase();
                    if (marker.includes('expand') || marker.includes('params') || marker.includes('properties') || text.includes('показать все') || text.includes('все характеристики') || text.includes('развернуть')) {
                        btn.click();
                    }
                }
            });
        });
    } catch (e) {}
}

function extractCharacteristicsFromDom() {
    const characteristics = {};

    safelyExpandCharacteristicsDom();

    const STATS_BLACKLIST = new Set([
        'показы', 'просмотры', 'избранное', 'контакты', 'расходы', 'продвижение',
        'статистика', 'размещено', 'обновлено', 'номер объявления', 'продвинуть',
        'снять с публикации', 'редактировать', 'сообщения', 'звонки', 'доставка',
        'купить с доставкой', 'оплата', 'гарантия'
    ]);

    function addParam(key, val) {
        if (!key || typeof key !== 'string') return;
        const cleanKey = key.trim().replace(/:$/, '');
        const cleanVal = typeof val === 'string' ? val.trim() : String(val || '').trim();
        const lowerKey = cleanKey.toLowerCase();
        
        if (STATS_BLACKLIST.has(lowerKey) || lowerKey.startsWith('показ') || lowerKey.startsWith('просмотр') || lowerKey.startsWith('расход')) {
            return;
        }

        if (cleanKey && cleanVal && !characteristics[cleanKey]) {
            if (!cleanKey.startsWith('Показать') && !cleanKey.startsWith('Написать') && cleanKey.length < 100 && cleanVal.length < 500) {
                characteristics[cleanKey] = cleanVal;
            }
        }
    }

    const itemSelectors = [
        '[data-marker="item-view/item-params"] li',
        '[data-marker="item-view/item-params"] [class*="params-item"]',
        '[data-marker="item-properties/list"] li',
        '[data-marker="item-properties/item"]',
        '[data-marker="item-params/list"] li',
        '[data-marker*="params"] li',
        '[data-marker*="properties"] li',
        '[data-marker*="characteristics"] li',
        'ul[class*="params-paramsList"] li',
        'li[class*="params-paramsList__item"]',
        'li[class*="item-params-list-item"]',
        'li[class*="styles-module-root-"]',
        'div[class*="params-paramsList"] > div',
        'div[class*="params-item"]',
        'div[class*="item-params"]',
        '[data-marker="item-view/main"] [data-marker*="param"] li',
        '[data-marker="item-view/main"] [class*="param"] li'
    ].join(', ');

    const excludedContainers = '[data-marker="seller-info"], [data-marker*="seller"], [data-marker*="stats"], [class*="stats"], [class*="vas-"], [data-marker*="vas"], [data-marker="recommendations"], [data-marker="similar-items"], [data-marker="seller-items"], .recommendations-root, .similar-items';

    const elements = document.querySelectorAll(itemSelectors);
    elements.forEach(el => {
        if (el.closest && el.closest(excludedContainers)) return;

        let key = '';
        let val = '';

        const labelEl = el.querySelector('[class*="noaccent"], [class*="label"], [class*="title"], [class*="key"], [data-marker*="label"], [data-marker*="name"]');
        const valueEl = el.querySelector('[class*="accent"], [class*="value"], [class*="description"], [data-marker*="val"], [data-marker*="value"]');
        
        if (labelEl && valueEl && labelEl !== valueEl) {
            key = labelEl.textContent.trim().replace(/:$/, '');
            val = valueEl.textContent.trim();
        } else if (labelEl) {
            const labelText = labelEl.textContent.trim();
            key = labelText.replace(/:$/, '').trim();
            const rawVal = el.textContent.replace(labelText, '').trim();
            val = rawVal.replace(/^[—–:\s]+/, '').trim();
        }

        // 2. If no labelEl found by class, check if first child is span/strong/b/a
        if (!key || !val) {
            const firstChild = el.firstElementChild;
            if (firstChild && firstChild.textContent.trim()) {
                const fText = firstChild.textContent.trim();
                const totalText = el.textContent.trim();
                if (totalText.length > fText.length) {
                    key = fText.replace(/:$/, '').trim();
                    val = totalText.replace(fText, '').trim().replace(/^[—–:\s]+/, '').trim();
                }
            }
        }

        // 3. Children array fallback
        if (!key || !val) {
            const children = Array.from(el.children).filter(c => c.textContent.trim());
            if (children.length >= 2) {
                key = children[0].textContent.trim().replace(/:$/, '');
                val = children.slice(1).map(c => c.textContent.trim()).filter(Boolean).join(', ');
            }
        }

        // 4. Colon / Dash separator fallback
        if (!key || !val) {
            const text = el.textContent.trim();
            if (text.includes(':')) {
                const idx = text.indexOf(':');
                key = text.slice(0, idx).trim();
                val = text.slice(idx + 1).trim();
            } else if (text.includes(' — ') || text.includes(' – ')) {
                const sep = text.includes(' — ') ? ' — ' : ' – ';
                const idx = text.indexOf(sep);
                key = text.slice(0, idx).trim();
                val = text.slice(idx + sep.length).trim();
            }
        }

        if (key && val) {
            addParam(key, val);
        }
    });

    const dts = document.querySelectorAll('dl dt');
    dts.forEach(dt => {
        if (dt.closest && dt.closest(excludedContainers)) return;
        const dd = dt.nextElementSibling;
        if (dd && dd.tagName && dd.tagName.toLowerCase() === 'dd') {
            addParam(dt.textContent, dd.textContent);
        }
    });

    return characteristics;
}

function extractAllCharacteristics(jsonLd, itemId) {
    const combined = {};

    if (pageInitialData) {
        const stateParams = extractCharacteristicsFromJsonObject(pageInitialData, itemId);
        Object.assign(combined, stateParams);
    }

    const scripts = document.querySelectorAll('script');
    for (const script of scripts) {
        const text = script.textContent || '';
        if (text.includes('__initialData__') || text.includes('__NEXT_DATA__') || text.includes('__INITIAL_STATE__') || text.includes('window.__state__') || text.includes('initialData')) {
            for (const varName of ['__initialData__', '__INITIAL_STATE__', '__NEXT_DATA__', 'window.__state__', 'initialData', '__state__']) {
                if (text.includes(varName)) {
                    const parsed = extractJsonAssignedToVar(text, varName);
                    if (parsed) {
                        const scriptParams = extractCharacteristicsFromJsonObject(parsed, itemId);
                        for (const [k, v] of Object.entries(scriptParams)) {
                            if (!combined[k]) combined[k] = v;
                        }
                    }
                }
            }
        }
    }

    const jsonLdParams = extractCharacteristicsFromJsonLd(jsonLd);
    for (const [k, v] of Object.entries(jsonLdParams)) {
        if (!combined[k]) combined[k] = v;
    }

    const domParams = extractCharacteristicsFromDom();
    for (const [k, v] of Object.entries(domParams)) {
        if (!combined[k]) combined[k] = v;
    }

    return combined;
}

async function walkAndCollectAllGalleryPhotos() {
    const collectedHighResUrls = new Set();

    function inspectAndCollectFromMainFrame() {
        const mainFrame = document.querySelector('[data-marker="image-frame/image-wrapper"]') ||
                          document.querySelector('[data-marker="image-frame"]') ||
                          document.querySelector('.style-item-view-gallery-') ||
                          document.querySelector('.gallery-root') ||
                          document.querySelector('[data-marker="item-view/gallery"]') ||
                          document.querySelector('[data-marker="item-view/main"]');
        if (!mainFrame) return;

        // 1. Check sources in picture
        const sources = mainFrame.querySelectorAll('source[srcset], source[data-srcset]');
        sources.forEach(s => {
            const srcset = s.getAttribute('srcset') || s.getAttribute('data-srcset');
            if (srcset) {
                const candidates = parseSrcsetCandidates(srcset);
                if (candidates.length > 0) {
                    collectedHighResUrls.add(candidates[0].url);
                }
            }
        });

        // 2. Check main images
        const imgs = mainFrame.querySelectorAll('img');
        imgs.forEach(img => {
            const srcset = img.getAttribute('srcset') || img.getAttribute('data-srcset');
            if (srcset) {
                const candidates = parseSrcsetCandidates(srcset);
                if (candidates.length > 0) {
                    collectedHighResUrls.add(candidates[0].url);
                }
            }
            if (img.src && !img.src.startsWith('data:') && validateListingImageUrl(img.src)) {
                collectedHighResUrls.add(img.src);
            }
            if (img.dataset && img.dataset.src && validateListingImageUrl(img.dataset.src)) {
                collectedHighResUrls.add(img.dataset.src);
            }
        });
    }

    // Initial capture from main frame
    inspectAndCollectFromMainFrame();

    // Find all thumbnail elements in gallery list
    const thumbSelectors = [
        'ul[data-marker="gallery/list"] li',
        'ul[data-marker="gallery/list"] > *',
        '[data-marker="gallery/list"] [data-marker*="image"]',
        '[data-marker="gallery/preview-item"]',
        '[data-marker*="preview"]',
        '[data-marker="item-view/gallery"] ul li',
        '[data-marker="gallery"] ul li',
        'div[class*="gallery-list"] > *',
        'div[class*="style-gallery-list"] li',
        'ul[class*="gallery-list"] li'
    ].join(', ');

    const thumbs = Array.from(document.querySelectorAll(thumbSelectors)).filter(el => {
        if (el.closest && (el.closest('[data-marker*="seller"]') || el.closest('[data-marker*="recommend"]') || el.closest('[data-marker*="similar"]'))) {
            return false;
        }
        return true;
    });

    if (thumbs.length > 0) {
        for (let i = 0; i < thumbs.length; i++) {
            const thumb = thumbs[i];
            try {
                if (typeof thumb.scrollIntoView === 'function') {
                    thumb.scrollIntoView({ block: 'nearest', inline: 'center' });
                }
                const clickTarget = thumb.querySelector('button, img, a') || thumb;
                clickTarget.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true, cancelable: true }));
                clickTarget.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true }));
                clickTarget.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
                clickTarget.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
                clickTarget.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true }));
                clickTarget.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
                clickTarget.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
                if (typeof clickTarget.click === 'function') {
                    clickTarget.click();
                }
            } catch (e) {}

            await new Promise(r => setTimeout(r, 120));
            inspectAndCollectFromMainFrame();
        }

        // Restore first thumbnail
        try {
            const firstTarget = thumbs[0].querySelector('button, img, a') || thumbs[0];
            if (typeof firstTarget.click === 'function') firstTarget.click();
        } catch (e) {}
    } else {
        // Arrow-based fallback if no list items
        const nextBtn = document.querySelector('[data-marker="image-frame/next-button"], [data-marker="gallery/next-btn"], [aria-label*="Следующ"], [class*="arrow-right"]');
        if (nextBtn) {
            for (let step = 0; step < 15; step++) {
                try {
                    nextBtn.dispatchEvent(new MouseEvent('click', { bubbles: true }));
                    if (typeof nextBtn.click === 'function') nextBtn.click();
                } catch (e) {}
                await new Promise(r => setTimeout(r, 140));
                const prevCount = collectedHighResUrls.size;
                inspectAndCollectFromMainFrame();
                if (collectedHighResUrls.size === prevCount && step > 2) {
                    break;
                }
            }
        }
    }

    return Array.from(collectedHighResUrls);
}

function extractListingData(extraPhotos = []) {
    try {
        const url = window.location.href;
        const itemId = extractAvitoItemId(url, document.documentElement.innerHTML) || "unknown";

        const jsonLd = parseJsonLd();

        let title = "";
        if (jsonLd && jsonLd.name) title = jsonLd.name;
        if (!title) {
            const titleEl = document.querySelector('h1[data-marker="item-view/title-info"]') || document.querySelector('h1') || document.querySelector('[class*="title-info-title"]');
            if (titleEl) title = titleEl.textContent.trim();
        }
        if (!title) {
            title = document.title ? document.title.replace(/\s*—\s*купить.*$/i, '').trim() : "Объявление Avito";
        }

        let price = null;
        if (jsonLd && jsonLd.offers && jsonLd.offers.price) {
            price = parseFloat(jsonLd.offers.price);
        }
        if (!price) {
            const priceEl = document.querySelector('[data-marker="item-view/item-price"]') || document.querySelector('.js-item-price') || document.querySelector('[itemprop="price"]');
            if (priceEl) {
                const priceText = priceEl.textContent.replace(/\s+/g, '').replace(/[^0-9]/g, '');
                if (priceText) price = parseFloat(priceText);
            }
        }

        let description = "";
        if (jsonLd && jsonLd.description) description = jsonLd.description;
        if (!description) {
            const descEl = document.querySelector('[data-marker="item-view/item-description"]') || document.querySelector('.item-description-text') || document.querySelector('[itemprop="description"]');
            if (descEl) description = descEl.textContent.trim();
        }

        let category = "";
        try {
            const breadcrumbContainers = document.querySelectorAll('[data-marker="breadcrumbs"], nav[aria-label="Хлебные крошки"], .breadcrumbs-root');
            let crumbs = [];
            if (breadcrumbContainers.length > 0) {
                const links = breadcrumbContainers[0].querySelectorAll('a, span[class*="link"], span[itemprop="name"]');
                links.forEach(el => {
                    const t = el.textContent.trim();
                    if (t && t !== '…' && t !== '...' && t !== 'Главная' && !crumbs.includes(t)) {
                        crumbs.push(t);
                    }
                });
            }
            if (crumbs.length === 0) {
                const allLinks = Array.from(document.querySelectorAll('[data-marker="breadcrumbs"] a, .breadcrumbs-link'))
                    .map(el => el.textContent.trim())
                    .filter(t => t && t !== '…' && t !== '...' && t !== 'Главная');
                crumbs = Array.from(new Set(allLinks));
            }
            if (crumbs.length > 0) {
                category = crumbs.join(' / ');
            }
        } catch (e) {}

        let photos = [];
        try {
            photos = extractAllPhotos(jsonLd, extraPhotos);
        } catch (e) {}

        let characteristics = {};
        try {
            characteristics = extractAllCharacteristics(jsonLd, itemId);
        } catch (e) {}

        let brand = characteristics["Производитель"] || characteristics["Бренд"] || characteristics["Марка"] || null;
        let model = characteristics["Модель"] || null;

        // Model fallback from title if characteristics missed it
        if (!model && title) {
            const modelMatch = title.match(/(?:ASRock|Asus|Gigabyte|MSI|Intel|AMD|HP|Dell|Lenovo|Acer|Sinto|Huawei|Xiaomi|Apple|Samsung)\s+([A-Za-z0-9\-\.\/]+(?:\s+[A-Za-z0-9\-\.\/]+)*)/i);
            if (modelMatch && modelMatch[1]) {
                const candidateModel = modelMatch[1].replace(/\s+на\s+запчасти.*$/i, '').replace(/\s+б\/у.*$/i, '').trim();
                if (candidateModel && candidateModel.length >= 2 && candidateModel.length < 50) {
                    model = candidateModel;
                    if (!characteristics["Модель"]) {
                        characteristics["Модель"] = candidateModel;
                    }
                }
            }
        }

        return {
            schema_version: 1,
            extension_version: "0.2.17",
            captured_at: new Date().toISOString(),
            page_type: "listing",
            listing: {
                external_item_id: itemId,
                external_url: url,
                title: title || "Объявление Avito",
                price: price,
                description: description,
                category: category,
                brand: brand,
                model: model,
                status: "active",
                characteristics: characteristics,
                photos: photos
            }
        };
    } catch (err) {
        console.error("Technoreboot extractListingData fallback error:", err);
        return {
            schema_version: 1,
            extension_version: "0.2.17",
            captured_at: new Date().toISOString(),
            page_type: "listing",
            listing: {
                external_item_id: extractAvitoItemId(window.location.href, "") || "item",
                external_url: window.location.href,
                title: document.title || "Объявление Avito",
                price: null,
                description: "",
                category: "",
                status: "active",
                characteristics: {},
                photos: []
            }
        };
    }
}

function extractMyListingsData() {
    try {
        const items = [];
        const itemEls = document.querySelectorAll('[data-marker="item"], .styles-root-item, .item-snippet');
        itemEls.forEach(el => {
            const titleEl = el.querySelector('[data-marker="item-title"], .item-title-link, h3');
            const linkEl = el.querySelector('a[href*="/"]');
            const priceEl = el.querySelector('[data-marker="item-price"], .price');

            if (titleEl && linkEl) {
                const href = linkEl.getAttribute('href');
                const fullUrl = href.startsWith('http') ? href : 'https://www.avito.ru' + href;
                const itemId = extractAvitoItemId(fullUrl, el.innerHTML);
                const priceText = priceEl ? priceEl.textContent.replace(/\s+/g, '').replace(/[^0-9]/g, '') : null;

                items.push({
                    external_item_id: itemId,
                    external_url: fullUrl,
                    title: titleEl.textContent.trim(),
                    price: priceText ? parseFloat(priceText) : null,
                    status: "active"
                });
            }
        });
        return {
            schema_version: 1,
            extension_version: "0.2.17",
            captured_at: new Date().toISOString(),
            page_type: "my_listings",
            listings_count: items.length,
            items: items
        };
    } catch (e) {
        return {
            schema_version: 1,
            extension_version: "0.2.17",
            captured_at: new Date().toISOString(),
            page_type: "my_listings",
            listings_count: 0,
            items: []
        };
    }
}

async function walkAndCollectAllGalleryPhotos() {
    const collectedUrls = [];
    const seenUrls = new Set();

    function recordCurrentImages() {
        const imgs = document.querySelectorAll(
            '[data-marker="image-frame/image-wrapper"] img, [data-marker="gallery/image"] img, [data-marker*="gallery"] img, picture source, picture img, .gallery-img, .image-frame-wrapper img'
        );
        for (const img of imgs) {
            if (img.closest('[data-marker*="recommend"], [data-marker*="similar"], [class*="recommend"], [class*="similar"]')) continue;
            const srcset = img.getAttribute('srcset') || img.getAttribute('data-srcset');
            if (srcset) {
                const cands = parseSrcsetCandidates(srcset);
                for (const c of cands) {
                    const u = validateListingImageUrl(upgradeAvitoImageUrlToMaxQuality(c.url));
                    if (u && !seenUrls.has(u)) {
                        seenUrls.add(u);
                        collectedUrls.push(u);
                    }
                }
            }
            const src = img.src || img.getAttribute('data-src') || img.getAttribute('data-url');
            if (src) {
                const u = validateListingImageUrl(upgradeAvitoImageUrlToMaxQuality(src));
                if (u && !seenUrls.has(u)) {
                    seenUrls.add(u);
                    collectedUrls.push(u);
                }
            }
        }
    }

    recordCurrentImages();

    // Find gallery thumbnails
    const thumbSelectors = [
        '[data-marker="gallery/list"] li',
        '[data-marker="gallery/thumb"]',
        '[data-marker*="gallery-item"]',
        '[data-marker="slider-image"]',
        'ul[class*="gallery"] li',
        'div[class*="thumbnail"]',
        'div[class*="preview"]'
    ];
    const thumbs = Array.from(document.querySelectorAll(thumbSelectors.join(',')))
        .filter(isElementVisible)
        .filter(t => !t.closest('[data-marker*="recommend"], [data-marker*="similar"], [class*="recommend"], [class*="similar"]'));

    if (thumbs.length > 0) {
        for (let i = 0; i < Math.min(thumbs.length, 30); i++) {
            const thumb = thumbs[i];
            try {
                thumb.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
                thumb.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
                thumb.click();
            } catch (e) {}
            await delay(120);
            recordCurrentImages();
        }
    } else {
        const nextBtn = document.querySelector('button[data-marker="gallery/next-button"], [class*="gallery-button-next"], [data-marker*="slider-next"]');
        if (nextBtn && isElementVisible(nextBtn) && !nextBtn.closest('[data-marker*="recommend"], [data-marker*="similar"]')) {
            for (let i = 0; i < 10; i++) {
                try {
                    nextBtn.click();
                } catch (e) {}
                await delay(150);
                recordCurrentImages();
            }
        }
    }

    return collectedUrls;
}

async function extractListingDataMultiPass() {
    try {
        safelyExpandCharacteristicsDom();

        // 1. Actively click through all gallery thumbnails to force Avito to load high-res photos
        let walkedPhotos = [];
        try {
            walkedPhotos = await walkAndCollectAllGalleryPhotos();
        } catch (err) {}

        // 2. Extract listing data with the actively collected high-res photos
        let data = extractListingData(walkedPhotos);
        return data;
    } catch (e) {
        return extractListingData();
    }
}

// ============================================================================
// STAGE 06A-R10B: SAFE BROWSER-ASSISTED AVITO PUBLICATION FORM ADAPTER
// ============================================================================

const DEFAULT_ADDRESS = "Свердловская область, Екатеринбург, улица Кузнецова, 10";

const DANGEROUS_ACTION_KEYWORDS = [
    "разместить",
    "опубликовать",
    "подать объявление",
    "отправить",
    "подтвердить",
    "оплатить",
    "купить",
    "продолжить",
    "далее",
    "готово",
    "сохранить и опубликовать",
    "перейти к оплате",
    "подключить тариф",
    "выбрать тариф",
    "черновик",
    "черновики",
    "мои объявления",
    "мои заказы",
    "сообщения",
    "профиль",
    "избранное",
    "корзина",
    "баланс",
    "кошелек",
    "выйти",
    "выход",
    "удалить"
];

const CORE_FIELD_ALIASES = {
    title: ["название", "заголовок", "название товара", "заголовок объявления", "что вы продаете", "что продаете", "что вы продаёте", "что продаёте", "title", "title input", "наименование"],
    description: ["описание", "описание товара", "текст объявления", "description"],
    price: ["цена", "стоимость", "цена товара", "price"],
    condition: ["состояние", "состояние товара", "condition"],
    brand: ["бренд", "производитель", "марка", "brand"],
    model: ["модель", "модель материнской платы", "модель устройства", "модель процессора", "модель видеокарты", "model"],
    address: ["местоположение", "адрес", "где находится товар", "город, улица, дом", "укажите адрес", "место сделки", "город", "адрес сделки", "адрес показа", "location", "address", "geo"]
};

function normalizeFieldLabel(label) {
    if (!label || typeof label !== 'string') return '';
    return label
        .trim()
        .replace(/\s+/g, ' ')
        .toLowerCase()
        .replace(/ё/g, 'е')
        .replace(/:$/, '');
}

function isElementVisible(el) {
    if (!el) return false;
    if (el.tagName === 'INPUT' && (el.type === 'radio' || el.type === 'checkbox')) {
        const parentLabel = el.closest('label, [role="radio"], [role="checkbox"], [class*="radio"], [class*="chip"], div');
        if (parentLabel && parentLabel !== el) {
            return isElementVisible(parentLabel);
        }
    }
    if (el.offsetParent === null && el.tagName !== 'BODY') return false;
    try {
        const style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden') {
            return false;
        }
        if (style.opacity === '0' && el.tagName !== 'INPUT') {
            return false;
        }
    } catch (e) {}
    return true;
}

function normalizeConditionValue(val) {
    if (!val) return '';
    const clean = normalizeFieldLabel(String(val));
    if (clean.includes('б/у') || clean.includes('бу') || clean.includes('б / у') || clean.includes('подержанн') || clean.includes('бывш') || clean.includes('used')) {
        return 'б/у';
    }
    if (clean.includes('нов') || clean.includes('new')) {
        return 'новое';
    }
    if (clean.includes('запчаст') || clean.includes('разбор') || clean.includes('parts')) {
        return 'на запчасти';
    }
    return clean;
}

function isDangerousControl(el) {
    if (!el) return false;
    
    // HARD SAFETY GUARD: Never click any <a> links with href
    if (el.tagName === 'A' || el.getAttribute('href') || el.closest('a[href]')) {
        return true;
    }

    // HARD SAFETY GUARD: Never touch anything in header, navigation, profile menu, or sidebar
    if (el.closest('header, nav, aside, footer, [class*="header"], [class*="navbar"], [class*="profile"], [class*="user"], [data-marker*="header"], [data-marker*="search-form"], [data-marker*="profile"]')) {
        return true;
    }

    const text = (
        (el.innerText || '') + ' ' +
        (el.textContent || '') + ' ' +
        (el.value || '') + ' ' +
        (el.getAttribute('aria-label') || '') + ' ' +
        (el.getAttribute('title') || '') + ' ' +
        (el.getAttribute('data-marker') || '')
    );
    const norm = normalizeFieldLabel(text);
    for (const kw of DANGEROUS_ACTION_KEYWORDS) {
        if (norm.includes(kw)) return true;
    }

    const isSubmit = el.tagName === 'BUTTON' && el.type === 'submit';
    if (isSubmit && (norm.includes('продолжить') || norm.includes('далее'))) return true;
    return false;
}

function forceClickElement(el) {
    if (!el) return;

    // HARD SAFETY GUARD: Never click any <a> navigation links or elements inside recommendations/header/profile
    if (el.tagName === 'A' || el.getAttribute('href') || el.closest('a[href]')) {
        return;
    }
    if (el.closest('header, nav, aside, footer, [class*="header"], [class*="navbar"], [class*="profile"], [class*="user"], [data-marker*="recommend"], [data-marker*="similar"], [class*="recommend"], [class*="similar"], [data-marker*="items-carousel"], [data-marker*="seller-items"], [class*="serp"]')) {
        return;
    }

    try {
        el.scrollIntoView({ block: 'center', inline: 'center' });
    } catch (e) {}
    try {
        el.focus();
    } catch (e) {}

    const rect = el.getBoundingClientRect();
    const clientX = rect.left + (rect.width > 0 ? rect.width / 2 : 10);
    const clientY = rect.top + (rect.height > 0 ? rect.height / 2 : 10);

    const mouseOpts = {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX: clientX,
        clientY: clientY,
        buttons: 1
    };

    const mouseUpOpts = {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX: clientX,
        clientY: clientY,
        buttons: 0
    };

    try { el.dispatchEvent(new PointerEvent('pointerover', mouseOpts)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mouseover', mouseOpts)); } catch (e) {}
    try { el.dispatchEvent(new PointerEvent('pointerdown', mouseOpts)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mousedown', mouseOpts)); } catch (e) {}
    try { el.dispatchEvent(new PointerEvent('pointerup', mouseUpOpts)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mouseup', mouseUpOpts)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('click', mouseOpts)); } catch (e) {}
    try { el.click(); } catch (e) {}

    // Also trigger on any inner button or clickable container
    const innerBtn = el.querySelector('button, [role="button"], input[type="radio"], input[type="checkbox"]');
    if (innerBtn && innerBtn !== el) {
        try { innerBtn.dispatchEvent(new MouseEvent('click', mouseOpts)); } catch (e) {}
        try { innerBtn.click(); } catch (e) {}
    }
}

function resolveFieldLabel(inputEl) {
    if (!inputEl) return '';

    // Direct check for textarea / rich description editors
    const tagName = inputEl.tagName.toUpperCase();
    const isContentEditable = inputEl.getAttribute('contenteditable') === 'true' || inputEl.isContentEditable;
    const roleAttr = (inputEl.getAttribute('role') || '').toLowerCase();

    if (tagName === 'TEXTAREA' || isContentEditable || roleAttr === 'textbox') {
        const placeholder = normalizeFieldLabel(inputEl.getAttribute('placeholder') || '');
        const nameAttr = normalizeFieldLabel(inputEl.getAttribute('name') || '');
        const dataMarker = normalizeFieldLabel(inputEl.getAttribute('data-marker') || '');
        const ariaLabel = normalizeFieldLabel(inputEl.getAttribute('aria-label') || '');

        if (placeholder.includes('описан') || placeholder.includes('подумайт') || placeholder.includes('расскаж') ||
            nameAttr.includes('description') || dataMarker.includes('description') || ariaLabel.includes('описан') ||
            tagName === 'TEXTAREA' || isContentEditable) {
            return 'описание';
        }
    }

    // 0. Placeholder check
    const placeholder = normalizeFieldLabel(inputEl.getAttribute('placeholder') || '');
    if (placeholder) {
        if (placeholder.includes('что вы прода') || placeholder.includes('что прода') || placeholder.includes('название') || placeholder.includes('заголовок')) {
            return 'название';
        }
        if (placeholder.includes('описание') || placeholder.includes('подумайт') || placeholder.includes('расскаж')) return 'описание';
        if (placeholder.includes('цена') || placeholder.includes('стоимость')) return 'цена';
        if (placeholder.includes('адрес') || placeholder.includes('местоположен') || placeholder.includes('город') || placeholder.includes('улиц') || placeholder.includes('где наход') || placeholder.includes('дом')) {
            return 'адрес';
        }
    }

    // 0.01. Direct data-marker check for common Avito inputs
    const dataMarker = normalizeFieldLabel(inputEl.getAttribute('data-marker') || '');
    if (dataMarker) {
        if (dataMarker.includes('description') || dataMarker.includes('params[200]')) return 'описание';
        if (dataMarker.includes('price') || dataMarker.includes('params[201]')) return 'цена';
        if (dataMarker.includes('title') || dataMarker.includes('params[100]')) return 'название';
        if (dataMarker.includes('location') || dataMarker.includes('address') || dataMarker.includes('geo')) return 'адрес';
    }

    // 0.1. Direct text if inputEl is a title/legend/heading/span element
    if (['LEGEND', 'H3', 'H4', 'H5', 'SPAN', 'P'].includes(tagName)) {
        const direct = (inputEl.innerText || inputEl.textContent || '').trim();
        if (direct && direct.length >= 2 && direct.length <= 60) {
            const clean = normalizeFieldLabel(direct);
            if (clean && !clean.includes('выберите') && !clean.includes('поиск')) return clean;
        }
    }

    // 1. Associated <label for="id">
    if (inputEl.id) {
        const labelEl = document.querySelector(`label[for="${inputEl.id}"]`);
        if (labelEl && labelEl.innerText) {
            const clean = normalizeFieldLabel(labelEl.innerText);
            if (clean) return clean;
        }
    }

    // 2. Enclosing <label> text
    const parentLabel = inputEl.closest('label');
    if (parentLabel && parentLabel.innerText) {
        const clean = normalizeFieldLabel(parentLabel.innerText);
        if (clean) return clean;
    }

    // 3. aria-label or aria-labelledby
    const ariaLabel = inputEl.getAttribute('aria-label');
    if (ariaLabel) {
        const clean = normalizeFieldLabel(ariaLabel);
        if (clean) return clean;
    }

    const ariaLabelledby = inputEl.getAttribute('aria-labelledby');
    if (ariaLabelledby) {
        const refEl = document.getElementById(ariaLabelledby);
        if (refEl && refEl.innerText) {
            const clean = normalizeFieldLabel(refEl.innerText);
            if (clean) return clean;
        }
    }

    // 4. Stable data-marker attribute
    if (dataMarker) {
        const clean = normalizeFieldLabel(dataMarker.replace(/-/g, ' '));
        if (clean && !clean.includes('input') && !clean.includes('field')) return clean;
    }

    // 5. Meaningful name attribute
    const nameAttr = inputEl.getAttribute('name');
    if (nameAttr) {
        const clean = normalizeFieldLabel(nameAttr.replace(/[-_]/g, ' '));
        if (clean && clean.length > 2) return clean;
    }

    // 6. Nearby title or legend in parent container
    const container = inputEl.closest('[class*="field"], [class*="item"], [class*="param"], [class*="row"], [class*="location"], [class*="address"], fieldset, div');
    if (container) {
        const headerEl = container.querySelector('legend, h3, h4, h5, [class*="title"], [class*="label"], [class*="name"], [data-marker*="title"], span');
        if (headerEl && headerEl !== inputEl && headerEl.innerText) {
            const clean = normalizeFieldLabel(headerEl.innerText);
            if (clean && clean.length < 50) return clean;
        }
    }

    return '';
}

function collapseOpenDropdowns() {
    try {
        // Dispatch Escape key to dismiss any open listboxes / modal dropdowns
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));
        document.dispatchEvent(new KeyboardEvent('keyup', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true }));

        // Dispatch benign background clicks to trigger React onClickOutside handlers
        document.body.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
        document.body.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
        document.body.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
    } catch (e) {}

    if (document.activeElement && typeof document.activeElement.blur === 'function') {
        document.activeElement.blur();
    }
}

function setReactInputValue(el, value) {
    if (!el) return;
    const strVal = String(value);

    // Support rich text / contenteditable editors
    if (el.getAttribute('contenteditable') === 'true' || el.isContentEditable) {
        try {
            el.focus();
            document.execCommand('selectAll', false, null);
            document.execCommand('insertText', false, strVal);
            if (!el.innerText || el.innerText.trim() === '') {
                el.innerText = strVal;
            }
            el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: strVal }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            el.dispatchEvent(new Event('blur', { bubbles: true }));
        } catch (e) {
            el.innerText = strVal;
        }
        return;
    }

    // Set value on DOM element using prototype descriptor to notify React/Vue/Angular state
    try {
        el.focus();
        const prototype = Object.getPrototypeOf(el);
        const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value') ||
                           Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value') ||
                           Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
        if (descriptor && descriptor.set) {
            descriptor.set.call(el, strVal);
        } else {
            el.value = strVal;
        }
    } catch (e) {
        el.value = strVal;
    }

    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
}

function matchCoreFieldRole(normalizedLabel) {
    if (!normalizedLabel) return null;
    for (const [role, aliases] of Object.entries(CORE_FIELD_ALIASES)) {
        for (const alias of aliases) {
            if (normalizedLabel === alias || normalizedLabel.startsWith(alias + ' ') || normalizedLabel.endsWith(' ' + alias)) {
                return role;
            }
        }
    }
    return null;
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function selectDropdownSuggestion(inputEl, targetValue) {
    if (!inputEl || !targetValue) return false;
    const strTarget = String(targetValue).trim();
    if (!strTarget) return false;

    const normTarget = normalizeFieldLabel(strTarget);
    const targetTokens = normTarget.split(/[\s\-_\/]+/).filter(t => t.length >= 2);

    const tagName = inputEl.tagName ? inputEl.tagName.toUpperCase() : '';

    // If native <select> element
    if (tagName === 'SELECT') {
        for (const opt of inputEl.options) {
            const optNorm = normalizeFieldLabel(opt.text || opt.value || '');
            if (optNorm === normTarget || optNorm.includes(normTarget) || normTarget.includes(optNorm)) {
                inputEl.value = opt.value;
                inputEl.dispatchEvent(new Event('change', { bubbles: true }));
                inputEl.dispatchEvent(new Event('input', { bubbles: true }));
                return true;
            }
        }
    }

    // 1. Focus and click to trigger dropdown activation
    try {
        inputEl.focus();
        inputEl.click();
    } catch (e) {}

    // 2. Set value on input using React property descriptor
    if (tagName === 'INPUT' || tagName === 'TEXTAREA') {
        setReactInputValue(inputEl, strTarget);
        inputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
        inputEl.dispatchEvent(new KeyboardEvent('keyup', { key: 'ArrowDown', bubbles: true }));
    } else {
        // Custom button or div combobox: click it to open menu
        forceClickElement(inputEl);
    }

    // 3. Option selectors across legitimate dropdown/listbox containers
    const optionSelectors = [
        '[role="listbox"] [role="option"]',
        '[role="listbox"] li',
        '[data-marker*="suggest-item"]',
        '[data-marker*="option-item"]',
        '[data-marker*="select-option"]',
        '[class*="suggest-item"]',
        '[class*="dropdown-item"]',
        '[class*="select-item"]'
    ];

    let bestMatch = null;

    // Poll for suggestion dropdown listbox to mount (up to 8 iterations * 100ms = 800ms)
    for (let wait = 0; wait < 8; wait++) {
        await delay(100);

        const candidateOptions = Array.from(document.querySelectorAll(optionSelectors.join(',')))
            .filter(isElementVisible)
            .filter(o => !isDangerousControl(o));

        if (candidateOptions.length === 0) continue;

        for (let i = 0; i < candidateOptions.length; i++) {
            const opt = candidateOptions[i];
            const span = opt.querySelector('span, [class*="text"], [class*="title"], [class*="name"]');
            const rawText = span && span.innerText ? span.innerText : (opt.innerText || opt.textContent || opt.getAttribute('data-marker') || '');
            const optText = normalizeFieldLabel(rawText);
            if (!optText) continue;

            // Strict match: exact or exact prefix (e.g. "HP", "Epson", "Canon")
            if (optText === normTarget || optText.startsWith(normTarget) || normTarget.startsWith(optText)) {
                bestMatch = opt;
                break;
            }
        }

        if (bestMatch) break;
    }

    if (bestMatch) {
        forceClickElement(bestMatch);
        try {
            inputEl.dispatchEvent(new Event('change', { bubbles: true }));
            inputEl.dispatchEvent(new Event('blur', { bubbles: true }));
        } catch (e) {}
        await delay(200);
        return true;
    }

    // Fallback: confirm value on input with Enter
    if (tagName === 'INPUT' || tagName === 'TEXTAREA') {
        inputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
        inputEl.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));
        inputEl.dispatchEvent(new Event('blur', { bubbles: true }));
        await delay(150);
        return true;
    }

    return false;
}

async function selectAddressSuggestion(inputEl, targetAddress) {
    if (!inputEl) return false;
    const addr = targetAddress || DEFAULT_ADDRESS;

    const currentVal = (inputEl.value || inputEl.innerText || inputEl.textContent || '').trim();
    const normCurrent = normalizeFieldLabel(currentVal);

    if (normCurrent.includes('кузнецов') && (normCurrent.includes('10') || normCurrent.includes('екатеринбург'))) {
        return true;
    }

    try {
        inputEl.focus();
        inputEl.click();
    } catch (e) {}

    // Set address value
    setReactInputValue(inputEl, addr);

    // Dispatch keyboard events so geocoder autocomplete triggers
    inputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
    inputEl.dispatchEvent(new KeyboardEvent('keyup', { key: 'ArrowDown', bubbles: true }));

    // Poll for address suggestions (up to 35 iterations * 100ms = 3.5s)
    const optionSelectors = [
        '[role="listbox"] [role="option"]',
        '[role="listbox"] li',
        '[data-marker*="suggest-item"]',
        '[data-marker*="address-suggest"]',
        '[data-marker*="geo-suggest"]',
        '[data-marker*="option-item"]',
        '[data-marker*="geo"] li',
        '[class*="suggest-item"]',
        '[class*="suggestions-item"]',
        '[class*="geo-suggest"]',
        '[class*="address-suggest"]',
        '[class*="dropdown-item"]',
        '[class*="select-item"]',
        '[class*="options-item"]',
        '[class*="popup"] [role="option"]',
        '[class*="popup"] li',
        'div[class*="suggest"] [role="button"]',
        'div[class*="suggest"] div[class*="item"]'
    ];

    let candidateOptions = [];
    for (let wait = 0; wait < 35; wait++) {
        await delay(100);

        candidateOptions = Array.from(document.querySelectorAll(optionSelectors.join(',')))
            .filter(isElementVisible)
            .filter(o => !isDangerousControl(o))
            .filter(o => {
                if (o.tagName === 'A' || o.getAttribute('href') || o.closest('a[href]')) return false;
                if (o.closest('header, nav, [data-marker*="header"], [data-marker*="search-form"]')) return false;
                return true;
            });

        if (candidateOptions.length > 0) break;
    }

    let bestMatch = null;
    if (candidateOptions.length > 0) {
        for (const opt of candidateOptions) {
            const span = opt.querySelector('span, [class*="text"], [class*="title"], [class*="name"]');
            const rawText = span && span.innerText ? span.innerText : (opt.innerText || opt.textContent || opt.getAttribute('data-marker') || '');
            const optText = normalizeFieldLabel(rawText);
            if (!optText) continue;

            if (optText.includes('кузнецов') && optText.includes('10')) {
                bestMatch = opt;
                break;
            }
            if (optText.includes('кузнецов')) {
                bestMatch = opt;
            }
            if (optText.includes('екатеринбург') && (optText.includes('кузнецов') || optText.includes('10'))) {
                bestMatch = opt;
                break;
            }
        }
    }

    if (bestMatch) {
        forceClickElement(bestMatch);
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));
        inputEl.dispatchEvent(new Event('blur', { bubbles: true }));
        await delay(300);

        // Check if there is a confirmation button in modal/popup (e.g. "Выбрать", "Применить", "Подтвердить")
        const confirmBtnSelectors = [
            'button[data-marker*="confirm"]',
            'button[data-marker*="apply"]',
            'button[data-marker*="save"]',
            '[class*="location"] button[class*="button-primary"]',
            '[class*="address"] button[class*="button-primary"]',
            '[class*="geo"] button[class*="button-primary"]',
            'button[class*="apply"]',
            'button[class*="confirm"]'
        ];
        const confirmBtns = Array.from(document.querySelectorAll(confirmBtnSelectors.join(',')))
            .filter(isElementVisible)
            .filter(b => !isDangerousControl(b));
        if (confirmBtns.length > 0) {
            forceClickElement(confirmBtns[0]);
            await delay(200);
        }

        collapseOpenDropdowns();
        await delay(200);
        return true;
    }

    // Fallback: press Enter on the input
    inputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    inputEl.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    inputEl.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    inputEl.dispatchEvent(new Event('change', { bubbles: true }));
    inputEl.dispatchEvent(new Event('blur', { bubbles: true }));
    await delay(200);
    collapseOpenDropdowns();
    return true;
}

const CATEGORY_HARDWARE_KEYWORDS = {
    printer: ['принтер', 'мфу', 'оргтехник', 'расходник', 'сканер', 'картридж', 'печать', 'струйн', 'лазерн', 'printer', 'mfu', 'laserjet', 'deskjet', 'pixma', 'laser', 'epson', 'canon', 'hp', 'brother', 'kyocera', 'xerox', 'pantum'],
    motherboard: ['материнск', 'motherboard', 'системная плата', 'комплектующ', 'плата', 'asrock', 'asus', 'gigabyte', 'msi', 'lga', 'am4', 'am5'],
    computer: ['компьютер', 'системный блок', 'пк', 'моноблок', 'десктоп', 'настольн', 'pc', 'desktop', 'station'],
    laptop: ['ноутбук', 'laptop', 'нетбук', 'ультрабук', 'thinkpad', 'macbook', 'notebook'],
    storage: ['жестк', 'ssd', 'hdd', 'накопител', 'диск', 'nvme', 'sata', 'kingston', 'samsung', 'crucial', 'wd', 'seagate'],
    gpu: ['видеокарт', 'gpu', 'graphics', 'geforce', 'radeon', 'rtx', 'gtx', 'rx', 'nvidia'],
    cpu: ['процессор', 'cpu', 'intel', 'amd', 'ryzen', 'core i', 'xeon'],
    ram: ['оперативн', 'памят', 'ram', 'ddr', 'ddr3', 'ddr4', 'ddr5'],
    monitor: ['монитор', 'экран', 'дисплей', 'monitor', 'display'],
    network: ['роутер', 'маршрутизатор', 'коммутатор', 'сетев', 'router', 'switch', 'tplink', 'mikrotik', 'keenetic']
};

function scoreCategorySuggestion(categoryText, packageData) {
    if (!categoryText || !packageData) return 0;
    const normText = normalizeFieldLabel(categoryText);
    if (!normText || normText.length < 2) return 0;

    let score = 0;
    const titleText = normalizeFieldLabel((packageData.title || '') + ' ' + (packageData.brand || '') + ' ' + (packageData.model || ''));

    // 1. Hardware keyword domain matches
    for (const [catKey, keywords] of Object.entries(CATEGORY_HARDWARE_KEYWORDS)) {
        const titleMatches = keywords.some(kw => titleText.includes(kw));
        if (titleMatches) {
            const catMatches = keywords.some(kw => normText.includes(kw));
            if (catMatches) {
                score += 200;
                break;
            }
        }
    }

    // 2. Direct packageData.category match
    if (packageData.category) {
        if (typeof packageData.category === 'string') {
            const normCatName = normalizeFieldLabel(packageData.category);
            if (normCatName && (normText.includes(normCatName) || normCatName.includes(normText))) score += 180;
        } else if (typeof packageData.category === 'object') {
            if (packageData.category.display_name) {
                const normCatName = normalizeFieldLabel(packageData.category.display_name);
                if (normCatName && (normText.includes(normCatName) || normCatName.includes(normText))) score += 180;
            }
            if (Array.isArray(packageData.category.observed_path)) {
                for (const pathItem of packageData.category.observed_path) {
                    const normPath = normalizeFieldLabel(pathItem);
                    if (normPath && (normText.includes(normPath) || normPath.includes(normText))) {
                        score += 150;
                        break;
                    }
                }
            }
        }
    }

    // 3. Direct match with characteristics['Категория'] or ['Вид товара']
    const characteristics = packageData.characteristics || {};
    for (const [key, val] of Object.entries(characteristics)) {
        if (key.toLowerCase().includes('категор') || key.toLowerCase().includes('вид товара') || key.toLowerCase().includes('тип')) {
            const normVal = normalizeFieldLabel(String(val));
            if (normVal && (normText.includes(normVal) || normVal.includes(normText))) {
                score += 170;
                break;
            }
        }
    }

    // 4. Token overlap with title
    const tokens = titleText.split(/[\s,.\-_/]+/).filter(t => t.length >= 3);
    let matchedTokens = 0;
    for (const tok of tokens) {
        if (normText.includes(tok)) matchedTokens++;
    }
    score += (matchedTokens * 30);

    // 5. Broad category matching (e.g. root category "Электроника" or "Бытовая техника")
    const isHardware = Object.values(CATEGORY_HARDWARE_KEYWORDS).some(keywords => keywords.some(kw => titleText.includes(kw)));
    if (isHardware && (normText.includes('электроник') || normText.includes('оргтехник') || normText.includes('компьютер'))) {
        score += 160;
    } else if (normText === 'электроника' || normText === 'товары' || normText === 'бытовая техника' || normText.includes('электроник')) {
        score += 50;
    }

    return score;
}

function matchCategorySuggestion(categoryText, packageData) {
    return scoreCategorySuggestion(categoryText, packageData) > 0;
}

function findCategorySuggestTiles() {
    const titleInput = document.querySelector(
        'input[data-marker*="title"], input[placeholder*="Что вы прода"], input[placeholder*="Что прода"], input[placeholder*="Название"], input[name*="title"], input[name*="name"]'
    );

    const selectors = [
        '[data-marker*="suggested-categories"] button',
        '[data-marker*="suggested-categories"] [role="button"]',
        '[data-marker*="suggested-categories"] li',
        '[data-marker*="suggested-categories"] div[class*="item"]',
        '[data-marker*="suggested-categories"] div[tabindex]',
        '[data-marker*="suggested-category"]',
        '[data-marker*="suggested-rubric"]',
function findCategorySuggestTiles(titleInput) {
    const selectors = [
        '[data-marker*="suggested-category"]',
        '[data-marker*="suggested-rubric"]',
        '[data-marker*="category-suggest"] button',
        '[data-marker*="category-suggest"] [role="button"]',
        '[data-marker*="category-suggest"] li',
        '[data-marker*="category-prediction"]',
        '[data-marker*="rubricator"] button',
        '[data-marker*="rubricator"] [role="button"]',
        '[data-marker*="rubricator"] li',
        '[class*="suggestedCategory"]',
        '[class*="suggested-categories"] button',
        '[class*="suggested-categories"] [role="button"]',
        '[class*="suggested-categories"] li',
        '[class*="category-tile"]',
        '[class*="categoryTile"]',
        '[class*="categorySuggestion"]',
        '[class*="categorySuggest"]',
        '[class*="rubricator"] button',
        '[class*="rubricator"] li'
    ];

    const formRoot = document.querySelector('form, [class*="form"], [data-marker*="form"], [class*="add-item"], [class*="step"]') || document;
    const found = Array.from(formRoot.querySelectorAll(selectors.join(',')))
        .filter(isElementVisible)
        .filter(t => !isDangerousControl(t))
        .filter(t => !t.closest('[data-marker*="recommend"], [data-marker*="similar"], [class*="recommend"], [class*="similar"], [data-marker*="items-carousel"], [data-marker*="seller-items"], [class*="serp"], header, nav, aside, footer'));

    const unique = [];
    const seen = new Set();
    for (const t of found) {
        if (!t || seen.has(t)) continue;
        if (t.tagName === 'A' || t.getAttribute('href') || t.closest('a[href]')) continue;
        seen.add(t);
        unique.push(t);
    }
    return unique;
}

async function handleCategorySuggestions(packageData, report, filledCoreRoles, filledCharacteristicKeys) {
    if (filledCoreRoles.has('category')) {
        return 0;
    }

    let totalClicks = 0;

    // Up to 3 levels of category drilldown (e.g. Root "Электроника" -> Subcat "Оргтехника и расходники" -> Leaf "Принтеры")
    for (let level = 0; level < 3; level++) {
        let tiles = findCategorySuggestTiles();

        // Short poll up to 6 * 100ms = 600ms on each level
        if (tiles.length === 0) {
            for (let w = 0; w < 6; w++) {
                await delay(100);
                tiles = findCategorySuggestTiles();
                if (tiles.length > 0) break;
            }
        }

        if (tiles.length === 0) {
            break;
        }

        let bestTile = null;
        let bestScore = -1;
        let bestText = '';

        for (let i = 0; i < tiles.length; i++) {
            const tile = tiles[i];
            const span = tile.querySelector('span, [class*="text"], [class*="title"], [class*="name"]');
            const rawCatText = span && span.innerText ? span.innerText : (tile.innerText || tile.textContent || tile.getAttribute('data-marker') || '');
            const cleanCatText = rawCatText.trim();
            if (!cleanCatText) continue;

            let score = scoreCategorySuggestion(cleanCatText, packageData);
            if (score > 0) {
                score += (tiles.length - i);
            }

            if (score > bestScore) {
                bestScore = score;
                bestTile = tile;
                bestText = cleanCatText;
            }
        }

        // STRICT SAFETY: Only click if score >= 50 (strong relevant match). Never click blind default tiles.
        if (bestTile && bestScore >= 50) {
            const cleanText = bestText.trim() || 'Предложенная категория';
            forceClickElement(bestTile);
            totalClicks++;

            if (level === 0) {
                report.filled.push({ source: 'category', target: 'категория', value: cleanText, type: 'category-tile' });
                filledCharacteristicKeys.add('Категория');
                filledCharacteristicKeys.add('категория');
                filledCharacteristicKeys.add('Вид товара');
                filledCharacteristicKeys.add('вид товара');
            }

            await delay(350);

            // Check if Step 1 has a "Продолжить" / "Далее" button that needs to be clicked
            const formRoot = document.querySelector('form, [class*="form"], [data-marker*="form"], [class*="add-item"], [class*="step"]') || document;
            const nextBtnSelectors = [
                'button[data-marker*="submit"]',
                'button[data-marker*="continue"]',
                'button[data-marker*="next"]',
                'button[class*="button-primary"]',
                'button[type="submit"]'
            ];
            const nextBtns = Array.from(formRoot.querySelectorAll(nextBtnSelectors.join(',')))
                .filter(isElementVisible)
                .filter(b => !isDangerousControl(b))
                .filter(b => {
                    const txt = normalizeFieldLabel(b.innerText || b.textContent || '');
                    return (txt.includes('продолжить') || txt.includes('далее') || txt.includes('следующ'));
                });
            if (nextBtns.length > 0) {
                forceClickElement(nextBtns[0]);
                await delay(350);
            }

            // Check if Step 2 has mounted (price/condition/description inputs appeared)
            const step2Mounted = Array.from(formRoot.querySelectorAll('input[data-marker*="price"], input[placeholder*="Цена"], textarea, [data-marker*="condition"], [data-marker*="description"]')).some(isElementVisible);
            if (step2Mounted) {
                filledCoreRoles.add('category');
                break;
            }
        } else {
            break;
        }
    }

    if (totalClicks > 0) {
        filledCoreRoles.add('category');
        return 1;
    }

    return 0;
}

async function fillAvitoPublicationFormAsync(packageData) {
    const report = {
        product_id: packageData ? packageData.product_id : null,
        page_url: window.location.href,
        filled: [],
        skipped_nonempty: [],
        unresolved_fields: [],
        unresolved_options: [],
        protected_actions: [],
        errors: []
    };

    if (!packageData) {
        report.errors.push("Missing publication package");
        return report;
    }

    const characteristics = packageData.characteristics || {};
    const filledCharacteristicKeys = new Set();
    const filledCoreRoles = new Set();
    const maxPasses = 6;

    // Multi-pass cascading filling loop
    for (let pass = 0; pass < maxPasses; pass++) {
        let passChanges = 0;

        // 0. Check for initial Title & Category Step (on /additem)
        const formContainer = document.querySelector('form, [class*="form"], [data-marker*="form"], [class*="add-item"], [class*="step"]') || document;
        const hasStep2FieldsAlready = Array.from(formContainer.querySelectorAll(
            'input[data-marker*="price"], input[placeholder*="Цена"], textarea, [data-marker*="condition"], [data-marker*="description"]'
        )).some(isElementVisible);

        if (hasStep2FieldsAlready) {
            filledCoreRoles.add('category');
        }

        const titleSelectors = [
            'input[data-marker*="title"]',
            'input[data-marker*="params[100]"]',
            'input[placeholder*="Что вы прода"]',
            'input[placeholder*="Что прода"]',
            'input[placeholder*="Название"]',
            'input[placeholder*="наименование"]',
            'input[placeholder*="товар"]',
            'input[name*="title"]',
            'input[name*="name"]',
            '[class*="titleInput"] input',
            '[class*="title-input"] input',
            '[class*="title"] input',
            '[class*="Title"] input'
        ];
        let titleInputs = Array.from(formContainer.querySelectorAll(titleSelectors.join(',')))
            .filter(isElementVisible)
            .filter(el => !isDangerousControl(el));

        if (titleInputs.length === 0 && !hasStep2FieldsAlready) {
            const firstTextInput = Array.from(formContainer.querySelectorAll('input[type="text"], input:not([type])'))
                .filter(isElementVisible)
                .filter(el => !isDangerousControl(el) && !el.closest('header, nav, [data-marker*="header"], [data-marker*="search-form"]'));
            if (firstTextInput.length > 0) {
                titleInputs.push(firstTextInput[0]);
            }
        }

        if (titleInputs.length > 0 && packageData.title && !filledCoreRoles.has('title')) {
            const titleEl = titleInputs[0];
            const curTitle = (titleEl.value || '').trim();
            if (curTitle === '' || normalizeFieldLabel(curTitle) !== normalizeFieldLabel(packageData.title)) {
                setReactInputValue(titleEl, packageData.title);
                titleEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
                titleEl.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true }));
                titleEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
                titleEl.dispatchEvent(new KeyboardEvent('keyup', { key: 'ArrowDown', bubbles: true }));

                report.filled.push({ source: 'title', target: 'название', value: packageData.title, type: 'text' });
                passChanges++;
            }
            filledCoreRoles.add('title');
            await delay(250);
        }

        if (!filledCoreRoles.has('category') && !hasStep2FieldsAlready) {
            const catChanges = await handleCategorySuggestions(packageData, report, filledCoreRoles, filledCharacteristicKeys);
            passChanges += catChanges;

            // If category was clicked, wait briefly for Step 2 parameters form to mount
            if (catChanges > 0) {
                for (let w = 0; w < 8; w++) {
                    const hasStep2Fields = Array.from(formContainer.querySelectorAll(
                        'input[data-marker*="price"], input[placeholder*="Цена"], textarea, [data-marker*="condition"], [data-marker*="description"], [data-marker*="location"], [data-marker*="address"]'
                    )).some(isElementVisible);
                    if (hasStep2Fields) break;
                    await delay(100);
                }
            }
        }

        // 1. Scan standard inputs, textareas, selects, comboboxes, and contenteditables INSIDE publication form
        const inputElements = Array.from(formContainer.querySelectorAll(
            'input, textarea, select, [role="combobox"], [contenteditable="true"], [role="textbox"], [data-marker*="description"], [data-marker*="location"], [data-marker*="address"]'
        )).filter(el => {
            if (!isElementVisible(el)) return false;
            if (isDangerousControl(el)) return false;
            // HARD EXCLUSION: Never touch recommendations, similar ads, carousels, or headers
            if (el.closest('[data-marker*="recommend"], [data-marker*="similar"], [class*="recommend"], [class*="similar"], [data-marker*="items-carousel"], [data-marker*="seller-items"], [class*="serp"], header, nav, aside, footer')) {
                return false;
            }
            return true;
        });

        for (const el of inputElements) {
            // HARD SAFETY GUARD: Never touch submit/continue buttons or dangerous actions
            if (isDangerousControl(el)) {
                report.protected_actions.push({
                    element: el.tagName,
                    marker: el.getAttribute('data-marker') || el.name || el.innerText || 'dangerous_action'
                });
                continue;
            }

            // HARD SAFETY GUARD: Never touch file upload inputs in R10B
            if (el.tagName === 'INPUT' && el.type === 'file') {
                continue;
            }

            // HARD SAFETY GUARD: Never touch password or hidden inputs
            if (el.tagName === 'INPUT' && (el.type === 'password' || el.type === 'hidden')) {
                continue;
            }

            const label = resolveFieldLabel(el);
            const normLabel = normalizeFieldLabel(label);
            if (!normLabel) continue;

            // Check if field matches a core field role (title, description, price, brand, model, condition, address)
            const coreRole = matchCoreFieldRole(normLabel);
            let targetValue = null;
            let sourceRoleName = null;

            if (coreRole) {
                if (coreRole === 'title' && packageData.title && !filledCoreRoles.has('title')) {
                    targetValue = packageData.title;
                    sourceRoleName = 'title';
                } else if (coreRole === 'description' && packageData.description && !filledCoreRoles.has('description')) {
                    targetValue = packageData.description;
                    sourceRoleName = 'description';
                } else if (coreRole === 'price' && packageData.price && !filledCoreRoles.has('price')) {
                    targetValue = String(packageData.price);
                    sourceRoleName = 'price';
                } else if (coreRole === 'brand' && packageData.brand && !filledCoreRoles.has('brand')) {
                    targetValue = packageData.brand;
                    sourceRoleName = 'brand';
                } else if (coreRole === 'model' && packageData.model && !filledCoreRoles.has('model')) {
                    targetValue = packageData.model;
                    sourceRoleName = 'model';
                } else if (coreRole === 'condition' && packageData.condition && !filledCoreRoles.has('condition')) {
                    targetValue = packageData.condition;
                    sourceRoleName = 'condition';
                } else if (coreRole === 'address' && !filledCoreRoles.has('address')) {
                    targetValue = packageData.address || DEFAULT_ADDRESS;
                    sourceRoleName = 'address';
                }
            }

            // Check if field matches a specific characteristic key (exact normalized matching)
            if (!targetValue) {
                for (const [charKey, charVal] of Object.entries(characteristics)) {
                    if (filledCharacteristicKeys.has(charKey)) continue;
                    const normCharKey = normalizeFieldLabel(charKey);
                    if (normCharKey === normLabel) {
                        targetValue = String(charVal);
                        sourceRoleName = charKey;
                        break;
                    }
                }
            }

            if (!targetValue) continue;

            // Check if this is an Address / Location geocoding field
            if (sourceRoleName === 'address' || normLabel.includes('адрес') || normLabel.includes('местоположен') || normLabel.includes('где наход')) {
                const addrVal = targetValue || packageData.address || DEFAULT_ADDRESS;
                const setAddr = await selectAddressSuggestion(el, addrVal);
                if (setAddr) {
                    report.filled.push({ source: 'address', target: normLabel, value: addrVal, type: 'address-suggest' });
                    passChanges++;
                    filledCoreRoles.add('address');
                    filledCharacteristicKeys.add('Адрес');
                    filledCharacteristicKeys.add('адрес');
                    filledCharacteristicKeys.add('Местоположение');
                    filledCharacteristicKeys.add('местоположение');
                }
                continue;
            }

            // Check if input is a Combobox / Autocomplete / Suggestion Dropdown
            const isCombobox = (
                el.getAttribute('role') === 'combobox' ||
                el.getAttribute('aria-autocomplete') === 'list' ||
                el.getAttribute('aria-haspopup') === 'listbox' ||
                (sourceRoleName === 'brand' || sourceRoleName === 'model') ||
                (el.placeholder && (el.placeholder.includes('Выберите') || el.placeholder.includes('Поиск'))) ||
                el.closest('[class*="suggest"], [class*="autocomplete"], [data-marker*="suggest"], [data-marker*="select"]') !== null
            );

            const tagName = el.tagName.toUpperCase();

            if (isCombobox || tagName === 'SELECT') {
                const currentVal = (el.value || el.innerText || el.textContent || '').trim();
                const normCurrentVal = normalizeFieldLabel(currentVal);
                const normTargetVal = normalizeFieldLabel(targetValue);

                if (currentVal !== '' && normCurrentVal.length > 1 && !normCurrentVal.includes('выберите') && !normCurrentVal.includes('поиск') && (normCurrentVal === normTargetVal || normCurrentVal.includes(normTargetVal) || normTargetVal.includes(normCurrentVal))) {
                    if (sourceRoleName) {
                        filledCoreRoles.add(sourceRoleName);
                        filledCharacteristicKeys.add(sourceRoleName);
                    }
                } else {
                    const selected = await selectDropdownSuggestion(el, targetValue);
                    if (selected) {
                        report.filled.push({ source: sourceRoleName, target: normLabel, value: targetValue, type: 'combobox' });
                        passChanges++;
                        if (sourceRoleName) {
                            filledCoreRoles.add(sourceRoleName);
                            filledCharacteristicKeys.add(sourceRoleName);
                        }
                    }
                }
                continue;
            }

            // Standard input types, textareas, and contenteditables
            if (tagName === 'INPUT' || tagName === 'TEXTAREA' || el.getAttribute('contenteditable') === 'true' || el.isContentEditable) {
                const inputType = (el.getAttribute('type') || (tagName === 'TEXTAREA' ? 'textarea' : 'text')).toLowerCase();

                if (inputType === 'radio') {
                    const optionText = normalizeFieldLabel((el.value || '') + ' ' + (resolveFieldLabel(el) || ''));
                    let isMatch = false;

                    if (sourceRoleName === 'condition' || normLabel.includes('состояни')) {
                        isMatch = normalizeConditionValue(optionText) === normalizeConditionValue(targetValue);
                    } else {
                        const normTargetVal = normalizeFieldLabel(targetValue);
                        isMatch = (optionText.includes(normTargetVal) || normTargetVal.includes(optionText));
                    }

                    if (isMatch) {
                        if (el.checked) {
                            report.skipped_nonempty.push({ target: normLabel, existing_value: el.value || optionText });
                            if (sourceRoleName) {
                                filledCoreRoles.add(sourceRoleName);
                                filledCharacteristicKeys.add(sourceRoleName);
                            }
                        } else {
                            forceClickElement(el);
                            el.dispatchEvent(new Event('change', { bubbles: true }));
                            report.filled.push({ source: sourceRoleName, target: normLabel, value: targetValue, type: 'radio' });
                            passChanges++;
                            if (sourceRoleName) {
                                filledCoreRoles.add(sourceRoleName);
                                filledCharacteristicKeys.add(sourceRoleName);
                            }
                        }
                    }
                } else if (inputType === 'checkbox') {
                    const optionText = normalizeFieldLabel((el.value || '') + ' ' + (resolveFieldLabel(el) || ''));
                    const normTargetVal = normalizeFieldLabel(targetValue);
                    if (optionText.includes(normTargetVal) || normTargetVal.includes(optionText)) {
                        if (el.checked) {
                            report.skipped_nonempty.push({ target: normLabel, existing_value: 'checked' });
                            if (sourceRoleName) {
                                filledCoreRoles.add(sourceRoleName);
                                filledCharacteristicKeys.add(sourceRoleName);
                            }
                        } else {
                            forceClickElement(el);
                            el.dispatchEvent(new Event('change', { bubbles: true }));
                            report.filled.push({ source: sourceRoleName, target: normLabel, value: targetValue, type: 'checkbox' });
                            passChanges++;
                            if (sourceRoleName) {
                                filledCoreRoles.add(sourceRoleName);
                                filledCharacteristicKeys.add(sourceRoleName);
                            }
                        }
                    }
                } else {
                    // Text, Number, Textarea, ContentEditable
                    const currentVal = (el.value || el.innerText || el.textContent || '').trim();
                    if (currentVal !== '') {
                        report.skipped_nonempty.push({ target: normLabel, existing_value: currentVal });
                        if (sourceRoleName) {
                            filledCoreRoles.add(sourceRoleName);
                            filledCharacteristicKeys.add(sourceRoleName);
                        }
                    } else {
                        setReactInputValue(el, targetValue);
                        report.filled.push({ source: sourceRoleName, target: normLabel, value: targetValue, type: inputType });
                        passChanges++;
                        if (sourceRoleName) {
                            filledCoreRoles.add(sourceRoleName);
                            filledCharacteristicKeys.add(sourceRoleName);
                        }

                        if (sourceRoleName === 'title') {
                            for (let w = 0; w < 15; w++) {
                                await delay(150);
                                const tiles = findCategorySuggestTiles();
                                if (tiles.length > 0) {
                                    const tileChanges = await handleCategorySuggestions(packageData, report, filledCoreRoles, filledCharacteristicKeys);
                                    passChanges += tileChanges;
                                    break;
                                }
                            }
                        }
                    }
                }
            } else if (tagName === 'SELECT') {
                const currentVal = (el.value || '').trim();
                const normTargetVal = normalizeFieldLabel(targetValue);
                let matchedOption = null;

                for (const opt of Array.from(el.options)) {
                    const optText = normalizeFieldLabel(opt.text || opt.value || '');
                    if (sourceRoleName === 'condition' || normLabel.includes('состояни')) {
                        if (normalizeConditionValue(optText) === normalizeConditionValue(targetValue)) {
                            matchedOption = opt;
                            break;
                        }
                    } else if (optText === normTargetVal || optText.includes(normTargetVal) || normTargetVal.includes(optText)) {
                        matchedOption = opt;
                        break;
                    }
                }

                if (matchedOption) {
                    if (el.selectedIndex > 0 && currentVal !== '' && currentVal === matchedOption.value) {
                        report.skipped_nonempty.push({ target: normLabel, existing_value: currentVal });
                        if (sourceRoleName) {
                            filledCoreRoles.add(sourceRoleName);
                            filledCharacteristicKeys.add(sourceRoleName);
                        }
                    } else if (el.selectedIndex > 0 && currentVal !== '' && el.selectedIndex !== 0) {
                        report.skipped_nonempty.push({ target: normLabel, existing_value: currentVal });
                        if (sourceRoleName) {
                            filledCoreRoles.add(sourceRoleName);
                            filledCharacteristicKeys.add(sourceRoleName);
                        }
                    } else {
                        el.value = matchedOption.value;
                        el.dispatchEvent(new Event('change', { bubbles: true }));
                        report.filled.push({ source: sourceRoleName, target: normLabel, value: matchedOption.text, type: 'select' });
                        passChanges++;
                        if (sourceRoleName) {
                            filledCoreRoles.add(sourceRoleName);
                            filledCharacteristicKeys.add(sourceRoleName);
                        }
                    }
                } else {
                    report.unresolved_options.push({ key: normLabel, expected: targetValue });
                }
            }
        }

        // 2. Scan segmented button groups / chip selectors (e.g. "Состояние", "Вид товара", "Тип", etc.) INSIDE publication form
        const groupContainers = Array.from(formContainer.querySelectorAll(
            'fieldset, [role="radiogroup"], [data-marker*="param"], [data-marker*="condition"], [class*="param"], [class*="field"], [class*="group"], [class*="chips"]'
        )).filter(c => {
            if (!isElementVisible(c)) return false;
            if (isDangerousControl(c)) return false;
            if (c.closest('[data-marker*="recommend"], [data-marker*="similar"], [class*="recommend"], [class*="similar"], [data-marker*="items-carousel"], [data-marker*="seller-items"], [class*="serp"], header, nav, aside, footer')) {
                return false;
            }
            return true;
        });

        for (const container of groupContainers) {
            const titleEl = container.querySelector('legend, h3, h4, h5, [class*="title"], [class*="label"], [class*="name"], [data-marker*="title"], span');
            const groupLabel = resolveFieldLabel(titleEl || container);
            const normGroupLabel = normalizeFieldLabel(groupLabel);
            if (!normGroupLabel) continue;

            const coreRole = matchCoreFieldRole(normGroupLabel);
            let targetValue = null;
            let sourceRoleName = null;

            if (coreRole) {
                if (coreRole === 'condition' && packageData.condition && !filledCoreRoles.has('condition')) {
                    targetValue = packageData.condition;
                    sourceRoleName = 'condition';
                } else if (coreRole === 'brand' && packageData.brand && !filledCoreRoles.has('brand')) {
                    targetValue = packageData.brand;
                    sourceRoleName = 'brand';
                } else if (coreRole === 'model' && packageData.model && !filledCoreRoles.has('model')) {
                    targetValue = packageData.model;
                    sourceRoleName = 'model';
                }
            }

            if (!targetValue) {
                for (const [charKey, charVal] of Object.entries(characteristics)) {
                    if (filledCharacteristicKeys.has(charKey)) continue;
                    const normCharKey = normalizeFieldLabel(charKey);
                    if (normCharKey === normGroupLabel) {
                        targetValue = String(charVal);
                        sourceRoleName = charKey;
                        break;
                    }
                }
            }

            if (!targetValue) continue;

            const candidateButtons = Array.from(container.querySelectorAll('button, [role="radio"], [role="button"], label, [data-marker*="item"]'))
                .filter(b => b !== container && b.getAttribute('role') !== 'radiogroup' && b.tagName !== 'FIELDSET' && b.tagName !== 'DIV')
                .filter(b => !b.closest('a[href]') && b.tagName !== 'A');

            for (const btn of candidateButtons) {
                if (!isElementVisible(btn)) continue;
                if (isDangerousControl(btn)) continue;

                let rawText = '';
                const span = btn.querySelector('span, [class*="text"], [class*="label"]');
                if (span && span.innerText) {
                    rawText = span.innerText;
                } else {
                    rawText = btn.innerText || btn.textContent || btn.getAttribute('aria-label') || btn.getAttribute('data-marker') || '';
                }
                const btnText = rawText.trim();
                const normBtnText = normalizeFieldLabel(btnText);
                if (!normBtnText) continue;

                let isMatch = false;
                if (sourceRoleName === 'condition' || normGroupLabel.includes('состояни')) {
                    isMatch = normalizeConditionValue(normBtnText) === normalizeConditionValue(targetValue);
                } else {
                    const normTarget = normalizeFieldLabel(targetValue);
                    isMatch = (normBtnText === normTarget || normBtnText.includes(normTarget) || normTarget.includes(normBtnText));
                }

                if (isMatch) {
                    const isSelected = (
                        btn.getAttribute('aria-checked') === 'true' ||
                        btn.getAttribute('aria-pressed') === 'true' ||
                        btn.classList.contains('active') ||
                        btn.classList.contains('selected') ||
                        btn.classList.contains('checked') ||
                        (btn.querySelector('input[type="radio"]:checked') !== null)
                    );

                    if (isSelected) {
                        report.skipped_nonempty.push({ target: normGroupLabel, existing_value: btnText });
                        if (sourceRoleName) {
                            filledCoreRoles.add(sourceRoleName);
                            if (sourceRoleName === 'condition') {
                                filledCharacteristicKeys.add('Состояние');
                                filledCharacteristicKeys.add('состояние');
                            } else {
                                filledCharacteristicKeys.add(sourceRoleName);
                            }
                        }
                    } else {
                        forceClickElement(btn);
                        btn.dispatchEvent(new Event('change', { bubbles: true }));
                        btn.dispatchEvent(new Event('input', { bubbles: true }));
                        report.filled.push({ source: sourceRoleName, target: normGroupLabel, value: btnText || targetValue, type: 'button-chip' });
                        passChanges++;
                        if (sourceRoleName) {
                            filledCoreRoles.add(sourceRoleName);
                            if (sourceRoleName === 'condition') {
                                filledCharacteristicKeys.add('Состояние');
                                filledCharacteristicKeys.add('состояние');
                            } else {
                                filledCharacteristicKeys.add(sourceRoleName);
                            }
                        }
                    }
                    break;
                }
            }
        }

        // 3. Standalone condition button fallback INSIDE formContainer
        if (packageData.condition && !filledCoreRoles.has('condition')) {
            const normCond = normalizeConditionValue(packageData.condition);
            const conditionButtons = Array.from(formContainer.querySelectorAll('button[data-marker*="condition"], [role="radio"][data-marker*="condition"], [class*="condition"] button'))
                .filter(b => b.tagName !== 'DIV' && b.tagName !== 'FIELDSET' && b.tagName !== 'FORM' && b.getAttribute('role') !== 'radiogroup')
                .filter(b => !b.closest('a[href]') && b.tagName !== 'A');
            for (const cBtn of conditionButtons) {
                if (!isElementVisible(cBtn)) continue;
                if (isDangerousControl(cBtn)) continue;

                let rawText = '';
                const span = cBtn.querySelector('span, [class*="text"], [class*="label"]');
                if (span && span.innerText) {
                    rawText = span.innerText;
                } else {
                    rawText = cBtn.innerText || cBtn.textContent || cBtn.getAttribute('data-marker') || '';
                }
                const btnText = rawText.trim();
                const marker = cBtn.getAttribute('data-marker') || '';

                if (normalizeConditionValue(btnText) === normCond || (marker && marker.toLowerCase().includes(normCond))) {
                    const isSelected = cBtn.getAttribute('aria-checked') === 'true' || cBtn.getAttribute('aria-pressed') === 'true' || cBtn.classList.contains('active') || cBtn.classList.contains('selected');
                    if (!isSelected) {
                        forceClickElement(cBtn);
                        cBtn.dispatchEvent(new Event('change', { bubbles: true }));
                        report.filled.push({ source: 'condition', target: 'состояние', value: btnText || packageData.condition, type: 'button-chip' });
                        passChanges++;
                        filledCoreRoles.add('condition');
                        filledCharacteristicKeys.add('Состояние');
                        filledCharacteristicKeys.add('состояние');
                        break;
                    }
                }
            }
        }

        // Collapse any lingering dropdown popups after pass on Step 2
        const hasStep2Filled = filledCoreRoles.has('price') || filledCoreRoles.has('condition') || filledCoreRoles.has('description') || filledCoreRoles.has('address');
        if (hasStep2Filled) {
            collapseOpenDropdowns();
        }

        // If this pass performed changes, wait for React cascading updates to render dependent fields
        if (passChanges > 0) {
            await delay(350);
        } else {
            // Reached steady state: no further fields mounted or unfulfilled on this step
            break;
        }
    }

    // Final cleanup: ensure all dropdowns are cleanly collapsed on Step 2
    if (filledCoreRoles.has('price') || filledCoreRoles.has('condition') || filledCoreRoles.has('description') || filledCoreRoles.has('address')) {
        collapseOpenDropdowns();
    }

    // Record unresolved characteristics that had no matching field mounted on this step
    for (const [charKey, charVal] of Object.entries(characteristics)) {
        if (!filledCharacteristicKeys.has(charKey) && !filledCharacteristicKeys.has(charKey.toLowerCase())) {
            report.unresolved_fields.push({ key: charKey, value: charVal });
        }
    }

    return report;
}

// Synchronous wrapper for unit tests
function fillAvitoPublicationForm(packageData) {
    let syncReport = null;
    fillAvitoPublicationFormAsync(packageData).then(r => { syncReport = r; });
    return syncReport || {
        product_id: packageData ? packageData.product_id : null,
        page_url: window.location.href,
        filled: [],
        skipped_nonempty: [],
        unresolved_fields: [],
        unresolved_options: [],
        protected_actions: [],
        errors: []
    };
}

// Runtime message dispatcher
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (!request) return true;

    if (request.action === "extract_current_page") {
        try {
            const url = window.location.href;
            if (url.includes('/profile/items') || url.includes('/my/items')) {
                sendResponse(extractMyListingsData());
            } else if (request.deepScan) {
                extractListingDataMultiPass()
                    .then(data => sendResponse(data || extractListingData()))
                    .catch(() => sendResponse(extractListingData()));
                return true;
            } else {
                sendResponse(extractListingData());
            }
        } catch (err) {
            try {
                sendResponse(extractListingData());
            } catch (e2) {
                sendResponse({
                    schema_version: 1,
                    extension_version: "0.2.22",
                    page_type: "listing",
                    listing: {
                        external_item_id: "item",
                        external_url: window.location.href,
                        title: document.title || "Объявление Avito",
                        price: null,
                        characteristics: {},
                        photos: []
                    }
                });
            }
        }
    } else if (request.action === "fill_avito_form") {
        fillAvitoPublicationFormAsync(request.package)
            .then(report => sendResponse(report))
            .catch(err => {
                sendResponse({
                    product_id: request.package ? request.package.product_id : null,
                    page_url: window.location.href,
                    filled: [],
                    skipped_nonempty: [],
                    unresolved_fields: [],
                    unresolved_options: [],
                    protected_actions: [],
                    errors: [String(err)]
                });
            });
        return true;
    }
    return true;
});


